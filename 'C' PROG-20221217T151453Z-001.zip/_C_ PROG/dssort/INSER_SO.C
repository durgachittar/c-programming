//this is isrtion sort sort,there are segments
#include<stdio.h>
#define size 5

void accept(int arr[])
{
	int i;
	for(i=0;i<=size-1;i++)
	{
		printf("enter the value at location %d=",i);
		scanf("%d",&arr[i]);
	}
}
void print(int arr[])
{
	int i;
	  for(i=0;i<=size-1;i++)
	 printf("  %d",arr[i]);
}

void insertion_sort(int arr[])
{
		int i,j,temp;

		for(i=1;i<size;i++)
		{
			temp=arr[i];
			for(j=i-1;j>=0 && temp<arr[j];j--)
			{
				arr[j+1]=arr[j];
			}
				arr[j+1]=temp;
				printf("\n");
				print(arr);
		}
}

main()
{
		int arr[size],i,j,temp;
		clrscr();
		accept(arr);
		insertion_sort(arr);
		printf("\nthe sorted list is\n");
		print(arr);
}