//sequetional search
#include <stdio.h>
#define size 10

/*typedef struct
{
	int empno;
	char empname[size],emp[job];
	float salary;
}emp;*/
void accept(int arr[],int s)
{
	int i;

		for(i=0;i<=s-1;i++)
		{

			printf("enter the value at location %d=",i);
			scanf("%d",&arr[i]);
		}
}
void print(int arr[],int s)
{
	int i;
	  for(i=0;i<=s-1;i++)
	 printf("  %d",arr[i]);
}
void bubble_sort(int arr[],int dim)
{
	int i,j,temp;
	for(i=0;i<dim;i++)
	{
		for(j=dim-1;j>i;j--)
		{
			if(arr[j]<arr[j-1])
			{
			temp=arr[j];
			arr[j]=arr[j-1];
			arr[j-1]=temp;
			}
		}
	}
}



int binary(int arr[],int val,int lb,int ub)
{
	int i,mid,x;
	 if(lb<ub)
	 {
		mid=(lb+ub)/2;
		if(val==arr[mid])
			return mid;
		else if(val > arr[mid])
		{
			lb=mid+1;
			binary(arr,val,lb,ub);
		}
		else if(val < arr[mid])
		{
			ub=mid -1;
			binary(arr,val,lb,ub);
		}
	 }
	 else
		return -1;
 }
int binary1(int arr[],int val,int lb,int ub)
{
	int mid;
	while(lb<ub)
	{
		mid=(lb+ub)/2;
		if(val==arr[mid])
			return mid;
		else if(val > arr[mid])
			lb=mid +1;
		else if(val < arr[mid])
			ub=mid-1;
	}
		return -1;
}


main()
{
	int arr[size],i,dim,j,m,flag=0,ch;
	clrscr();
	printf("\nenter the arr size");
	scanf("%d",&dim);

	accept(arr,dim);
	print(arr,dim);

	bubble_sort(arr,dim);
	printf("\n");
	print(arr,dim);

	printf("\n search item");
	scanf("%d",&j);

   //
   do
   {
	printf("\n1:binary search with recursion\n2:binary search without recursion\n3:exit\n");
	scanf("%d",&ch);

	switch(ch)
	{
		case 1:
			  flag=binary(arr,j,0,dim);
				if(flag==-1)
					printf("\n\nTHE ITEM IS NOT PRESENT");
				else
					printf("\nTHE ITEM IS PRESENT");
					break;
			case 2:
			   flag=binary1(arr,j,0,dim);
				if(flag==-1)
					printf("\nTHE ITEM IS NOT PRESENT");
				else
					printf("\nTHE ITEM IS PRESENT");
				break;
	}
	}while(ch!=3);



}

