//this is shell sort,there are segments
#include<stdio.h>
#define size 5

void accept(int arr[])
{
	int i;
		for(i=0;i<=size-1;i++)
	{
		printf("enter the value at location %d=",i);
		scanf("%d",&arr[i]);
	}
}
void print(int arr[])
{
	int i;
	  for(i=0;i<=size-1;i++)
	 printf("  %d",arr[i]);
}

void shell_sort(int arr[])
{
		int i,j,temp,min;
		min=(size-1)/2;
		while(min!=0)
		{
			for(i=min;i<size;i++)
			{
				temp=arr[i];
				j=i-min;
			while(j>=0 && temp<arr[j])
			{
				arr[j+min]=arr[j];
				j=j-min;
			}
				arr[j+min]=temp;
//				printf("%d  ",arr[j+min]);
		printf("\n");
			print(arr);
		}
			min/=2;
	}
}

main()
{
		int arr[size],i,j,temp;
		clrscr();
		accept(arr);
		shell_sort(arr);
}