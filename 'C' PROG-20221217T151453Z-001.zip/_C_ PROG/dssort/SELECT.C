//this is selection sort,1 ele compare with others eles
#include<stdio.h>
#define size 5
void accept(int arr[])
{
	int i;
		for(i=0;i<=size-1;i++)
	{
		printf("enter the value at location %d=",i);
		scanf("%d",&arr[i]);
	}
}
void print(int arr[])
{
	int i;
	  for(i=0;i<=size-1;i++)
	 printf("  %d",arr[i]);
}

void select_sort(int arr[])
{
		int i,j,temp,min;
		for(i=0;i<size;i++)
		{
			min=i;
			for(j=i+1;j<size;j++)
			{
				if(arr[j]<arr[min])
						min=j;
//				printf("\n");
  //				print(arr);
			}
				temp=arr[i];
				arr[i]=arr[min];
				arr[min]=temp;
				printf("\n");
				print(arr);
	}
}

main()
{
	int arr[size],i,j,temp;
	clrscr();
	accept(arr);
	select_sort(arr);
	printf("\nthe sorted list is");
	print(arr);
}