131.	MACRO WITH ARGUMENT 2.
		# define ISDIGIT(y) (y >= 48 && y <= 57)
		main()
		{
	int ch;
			printf ("Enter any digit  = ");
			scanf (�%d�,&ch);
			if (ISDIGIT(ch))
				{
				  printf (�\n You entered a digit�);
				}
	else
				{
				  printf ("\n Illegal input");	
				}
	}
