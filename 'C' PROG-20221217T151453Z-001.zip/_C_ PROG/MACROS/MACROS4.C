130.	MACRO WITH ARGUMENT 1.
		# define AREA(c) 3.142 x c x c
		main()
		{
			float r1 = 6.25, r2 = 2.5, a;
			a = AREA(r1);
			printf ("\n Area of circle is = %f",a);
			a = AREA(r2);
			printf ("\n Area of circle is = %f",a);
		}
