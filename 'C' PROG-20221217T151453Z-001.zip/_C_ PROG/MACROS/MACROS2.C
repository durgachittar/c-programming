128.	DEFINE NAME PI INSTEAD OF 3.1415.
	# define PI 3.1415
	main()
	{
		float r = 6.25, area;
		area = PI x r x r;
		printf ("\n Area of circle is = %f",area);
	}
