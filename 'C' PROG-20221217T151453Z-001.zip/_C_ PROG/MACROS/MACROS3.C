129.	DEFINE NAME AND FOR && AND OR FOR || 
	# define AND &&
	# define OR ||
	main()
	{
		int f = 1, x = 4, y = 90;
		if ((f < 5) AND (x< = 20 OR y < = 45))
		printf ("\n Your PC will always work fine...");
		else 
		printf ("\n In front of the maintenance 
