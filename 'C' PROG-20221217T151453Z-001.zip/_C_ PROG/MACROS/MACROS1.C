#include<stdio.h>
#include<conio.h>
# define size 5
void main()
{
int arr[size];
int i;
clrscr();
printf("enter the array element:-");
for(i=0;i<size;i++)
{
scanf("%d",&arr[i]);
}
printf("array element");
for(i=0;i<size;i++)
{
printf("%d\n",arr[i]);
}
}
/*macro:- it is preprocesser
#define-directive
size-macro template
value(s)-macro expansion*/
