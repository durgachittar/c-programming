#include<stdio.h>
#include<conio.h>
main()
{
/*
	153
	1*1*1 + 5*5*5 + 3*3*3
	1	  125	27
		153
		153,370,371,407
*/
int num,r,c,sum=0;
int no;
clrscr();
printf("Enter the no:");
scanf("%d",&num);
no=num;
while(num>0)
{
r=num%10;
c=r*r*r;
sum=sum+c;
num=num/10;
}
if(no==sum)
{
printf("number is Armstrong");
}
else
{
printf("number is not Armstrong");
}
}










