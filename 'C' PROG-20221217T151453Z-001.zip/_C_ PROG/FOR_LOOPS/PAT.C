		#include<stdio.h>
		#include<conio.h>

		/*
			Pattern
			1 2 3 4 5
		     1	* * * * *	i=1	j=1-5	*=5
		     2	* * * * *       i=2	j=1-5	*=5
		     3	* * * * *       i=3	j=1-5	*=5
		     4	* * * * *       i=4	j=1-5	*=5
		     5	* * * * *       i=5	j=1-5	*=5

		     nested for loop
		     for(init; condition; inc/dec)
		     {
			for(init; condition; inc/dec)
			{
			}
		     }
		*/
		void main()
		{
			int i,j;

			clrscr();
			for(i=1; i<=5; i++) //row
			{
				for(j=1; j<=5; j++) //col
				{
					printf("* ");
				}
				printf("\n");
			}
		}