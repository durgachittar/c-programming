#include<stdio.h>
#include<conio.h>
  #include<math.h>
  main()
  {
  int num,r,bin=0,i;
  clrscr();
  printf("Enter the number:");
  scanf("%d",&num);
  i=0;
  while(num>0)
  {
  r=num%2;
  bin=bin+(r*pow(10,i));
  i++;
  num=num/2;
  }
  printf("bin number=%d",bin);
  }

