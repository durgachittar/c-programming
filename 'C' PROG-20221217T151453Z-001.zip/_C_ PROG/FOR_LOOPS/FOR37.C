#include<conio.h>
#include<stdio.h>
main()
{
int mark1,mark2,mark3,total,stotal=0,i;
float avg,savg;
clrscr();
for(i=1;i<=5;i++)
{
printf("\n Enter mark of student:");
scanf("%d%d%d",&mark1,&mark2,&mark3);
total=mark1+mark2+mark3;
avg=(float)total/3;
stotal=total+stotal;
printf(" total=%d \t avg=%f ",total,avg);
}
savg=stotal/5;
printf("\nAerage of 5 student=%f/",savg);
getch();
}

