	#include<stdio.h>
	#include<conio.h>
	#include<math.h>
	void main()
	{
	int i,x;
	int sum=0;
	clrscr();
	printf("Enter the value of x:");
	scanf("%d",&x);
	for(i=1;i<=4;i++)
	{
	sum=sum+pow(x,i);
	}
	printf("%d",sum);
	getch();
	}
