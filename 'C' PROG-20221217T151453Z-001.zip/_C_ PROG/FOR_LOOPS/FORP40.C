#include<conio.h>
#include<stdio.h>
main()
{
int i,j;
clrscr();
for (i=1;i<=5;i++)
{
for(j=1;j<=i;j++)
{
printf ("%2d",j);
}
printf("\n\n");
}
getch();
}