#include<stdio.h>
#include<conio.h>
main()
{
int num,i,flag;
clrscr();
for(num=1;num<=30;num++)
{

flag=0;
for(i=2;i<=num/2;i++)
{
if(num%i==0)
{
flag=1;
break;
}
}
if(flag==0)
{
printf("%d\n",num);
}
}
}















