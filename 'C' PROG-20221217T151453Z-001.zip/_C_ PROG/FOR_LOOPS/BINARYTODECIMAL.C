  #include<stdio.h>
  #include<conio.h>
  #include<math.h>
  main()
  {
  int num,r,dec=0,i;
  clrscr();
  printf("Enter the number:");
  scanf("%d",&num);
  i=0;
  while(num>0)
  {
  r=num%10;
  dec=dec+(r*pow(2,i));
  i++;
  num=num/10;
  }
  printf("Decimal number=%d",dec);
  getch();
  }

