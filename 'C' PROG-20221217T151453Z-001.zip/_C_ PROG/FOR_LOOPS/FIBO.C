#include<conio.h>
#include<stdio.h>
main()
{
int a,b,c;
int num;
clrscr();
printf("Enter the number:");
scanf("%d",&num);
	a=0;
	b=1;
	c=0;
while(c<=num)
{
printf("%d\t",c);
a=b;
b=c;
c=a+b;
}
getch();
}


















