		#include<stdio.h>
		#include<conio.h>

		/*
			Pattern

		     * * * * *
		     * * * *
		     * * *
		     * *
		     *

		*/
		void main()
		{
			int i,j;

			clrscr();
			for(i=1; i<=5; i++) //row
			{
				for(j=5; j>=i; j--)
				{
					printf("* ");
				}
				printf("\n");
			}
		}