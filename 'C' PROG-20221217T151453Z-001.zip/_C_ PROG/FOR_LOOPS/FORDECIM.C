 #include<stdio.h>
  #include<conio.h>
  #include<math.h>
  main()
  {
  int num,r,bin=0,i;
  clrscr();
  printf("Enter the number:");
  scanf("%d",&num);
  i=0;
  for(;num>0;)
  {
  r=num%2;
  bin=bin+(r*pow(10,i));
  i++;
  num=num/2;
  }
  printf("Binary number=%d",bin);
  getch();
}