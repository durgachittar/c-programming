#include<stdio.h>
#include<conio.h>
main()
{
int num,sum=0;
clrscr();
printf("first 10 odd number:\n");
for(num=1;num<=20;num=num+2)
{
sum=sum+num;
printf("%d\n",num);
}
printf("sum of odd=%d",sum);
getch();
}





