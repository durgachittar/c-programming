		#include<stdio.h>
		#include<conio.h>

		/*
			Pattern

		     1	 			i=1	j=1	1
		     1 2	        	i=2	j=1-2	1-2
		     1 2 3	        	i=3	j=1-3	1-3
		     1 2 3 4	        	i=4	j=1-4	1-4
		     1 2 3 4 5		        i=5	j=1-5	1-5

		*/
		void main()
		{
			int i,j;

			clrscr();
			for(i=1; i<=5; i++) //row
			{
				for(j=1; j<=i; j++)
				{
					printf("%d ",j);
				}
				printf("\n");
			}
		}