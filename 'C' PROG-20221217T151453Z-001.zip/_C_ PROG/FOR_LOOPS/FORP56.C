#include<conio.h>
#include<stdio.h>
void main()
{
int i,ans;
clrscr();
for(i=1;i<=10;i++)
{
ans=i*2;
printf("%2d*2=%2d\n",i,ans);
}
getch();
}