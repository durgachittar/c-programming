

#include<conio.h>
#include<stdio.h>
void main()
{
int num,flag=0;   //prime
int i;
clrscr();
printf("Enter the number:");
scanf("%d",&num);
for(i=2;i<num;i++)
{
if(num%i==0)
{
flag=1;   // not prime
break;
}
}
if(flag==0)
{
printf("number is prime");
}
else
{
printf("number is not prime");
}
}






