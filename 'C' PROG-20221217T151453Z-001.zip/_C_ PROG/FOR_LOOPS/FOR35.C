#include<stdio.h>
#include<conio.h>
main()
{
int num,r,rev=0;
clrscr();
printf("Enter the number:");
scanf("%d",&num);
for(;num>0;num=num/10)
{
r=num%10;
rev=(rev*10)+r;
}
printf("Reverse num%d",rev);
getch();
}



















