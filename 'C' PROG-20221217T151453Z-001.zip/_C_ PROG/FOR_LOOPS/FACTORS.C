#include<conio.h>
#include<stdio.h>
main()
{
int num,i;
clrscr();
printf("Enter the number:");
scanf("%d",&num);
while(num>0)
{
for(i=2;i<=num;i++)
{
if(num%i==0)
{
printf("%d\n",i);
break;
}
}
num=num/i;
}
}








