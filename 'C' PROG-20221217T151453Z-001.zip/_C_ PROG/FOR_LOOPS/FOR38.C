#include<stdio.h>
#include<conio.h>
main()
{
int num,s,c;
clrscr();
printf("number square cube\n");
for(num=1;num<=10;num++)
{
s=num*num;
c=num*num*num;
printf("%d\t%d\t%d\n",num,s,c);
}
getch();
}