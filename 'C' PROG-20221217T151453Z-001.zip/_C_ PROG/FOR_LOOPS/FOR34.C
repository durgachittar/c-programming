main()
{
printf("HELLO WORLD")