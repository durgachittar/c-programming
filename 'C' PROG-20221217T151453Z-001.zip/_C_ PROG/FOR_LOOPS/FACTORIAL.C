#include<stdio.h>
#include<conio.h>
void main()
{
int num,i;
long int fact=1;
clrscr();
printf("Enter the number:");
scanf("%d",&num);
for(i=num;i>1;i--)
{
fact=fact*i;
}
printf("Factorial=%ld",fact);
}
