#include<conio.h>
#include<stdio.h>
main()
{
int num;
clrscr();
printf("reverse of first 10 number:\n");
for(num=10;num>=1;num--)
{
printf("%d\n",num);
}
getch();
}