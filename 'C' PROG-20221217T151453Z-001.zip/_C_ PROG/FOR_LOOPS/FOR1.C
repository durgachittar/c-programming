#include<stdio.h>
#include<conio.h>
main()
	 /*
		3.for loop
	syntax
	for(initilization;condition;increment/decrement)
	{
		statement
	}

  */
{
int num;
clrscr();
printf("first 10 odd number:\n");
for(num=1;num<=20;num=num+2)
{
printf("%d\n",num);
}
getch();
}

