	#include<stdio.h>
	#include<conio.h>

	void main()
	{
		int num;

		clrscr();
		num = 1; //init
		do
		{
			printf("%d\n",num);
			num++; //inc
		}while(num <= 10);//condition
	}