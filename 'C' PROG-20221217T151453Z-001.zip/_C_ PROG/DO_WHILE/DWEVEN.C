	#include<conio.h>
	#include<stdio.h>

	void main()
	{
	   int num;
	   int sum=0;
	   clrscr();
	   num=2;
	   do
	   {
		printf("%d\n",num);
	      sum=sum+num;
	      num=num+2;
	   }
	    while (num <=20);
	    printf("sum of first 10 even numbers=%d\n",sum);
	}