#include<stdio.h>
#include<conio.h>
void main()
{
int num;

clrscr();
num=10;//init
do
{

printf("%d\n",num);num=num-1;//num+2;//inc
}while(num>=0);//condition
}