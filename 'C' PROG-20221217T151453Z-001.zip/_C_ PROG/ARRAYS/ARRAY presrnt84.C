main()
{
int a[5],i,no,flag=0;
clrscr();

printf("Enter a number: ");
scanf("%d",&no);

printf("Enter five array elements:\n");
for(i=0;i<=4;i++)
scanf("%d",&a[i]);

for(i=0;i<5;i++)
{
if(a[i]==no)
flag=1;
}

if(flag==1)
printf("\nNumber is present");
else
printf("\nNumber is not present");

getch();
}