main()
{
int a[3][3],b[3][3],c[3][3],i,j,k;
clrscr();

printf("Enter first 3x3 matrix:\n");
for(i=0;i<3;i++)
{
for(j=0;j<3;j++)
{
scanf("%d",&a[i][j]);
}
}

printf("Enter first 3x3 matrix:\n");
for(i=0;i<3;i++)
{
for(j=0;j<3;j++)
{
scanf("%d",&b[i][j]);
}
}
printf("first matrix\n");
for(i=0;i<3;i++)
{
for(j=0;j<3;j++)
{
printf("%2d",a[i][j]);
}
printf("\n");
}
printf("second matrix\n");
for(i=0;i<3;i++)
{
for(j=0;j<3;j++)
{
printf("%2d",b[i][j]);
}
printf("\n");
}
printf("Multiplication of matrix:\n");
for(i=0;i<3;i++)         //row of matrix(a)
{
for(j=0;j<3;j++)       //col of matrix(b)
{
for(k=0;c[i][j]=0,k<3;k++) //element
{
c[i][j]=c[i][j]+(a[i][k]*b[k][j]);
}
printf("%2d",c[i][j]);
}
printf("\n");
}
getch();
}