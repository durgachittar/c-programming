	#include<stdio.h>
	#include<conio.h>

	void main()
	{
		int arr[5];
		int i;
		int sum=0;

		clrscr();
		for(i=0; i<5; i++)
		{
			printf("Enter the value of arr[%d] :",i);
			scanf("%d",&arr[i]);
			sum = sum + arr[i];
		}
		printf("Sum of array elements = %d",sum);

	}