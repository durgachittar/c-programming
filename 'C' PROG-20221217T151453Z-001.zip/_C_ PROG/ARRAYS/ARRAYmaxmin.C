     main()
     {
     int arr[5],i,j,max,min;
     clrscr();
     printf("Enter array elements :");
     for(i=0;i<5;i++)
     scanf("%d",&arr[i]);
      max=arr[0];
      min=arr[0];

     for(i=0;i<5;i++)
     {
     if(max<arr[i])
     max=arr[i];

     if(min>arr[i])
     min=arr[i];
     }
     printf("\nMax is %d",max);
     printf("\nMin is %d",min);
     getch();
     }