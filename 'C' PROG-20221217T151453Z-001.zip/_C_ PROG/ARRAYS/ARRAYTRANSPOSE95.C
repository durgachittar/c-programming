119.	TO OBTAIN TRANSPOSE OF A 4*4 MATRIX  
		main()
		{
			int a[3][3],i,j,k,r,c;
			printf ("Enter the no. of rows & cols = ");
			scanf ("%d %d",&r,&c);
			printf ("Enter a matrix = ");
			for (i = 0;i<r;i + +)
					for (j = 0;j<c;j + +)
					      gotoxy ((3 x j) + 5,(3 x i) + 5);
					      scanf ("%d",&a[i][j]);
			
			gotoxy (15,8);
			printf ("Transpose => ");
			
			for (i = 0;i<r;i + +)
					for (j = 0;j<c;j + +)
					      gotoxy ((3 x j) + 30,(3 x i) + 5);
					      printf ("%d",a[j][i]);
			}
