main()
{
int a[5],b[5],i,j;
clrscr();

printf("Enter first array:\n");
for(i=0;i<=4;i++)
scanf("%d",&a[i]);

printf("Enter second array:\n");
for(i=0;i<=4;i++)
scanf("%d",&b[i]);

printf("Common array elements:\n");
for(i=0;i<=4;i++)
{
for(j=0;j<=4;j++)
{
if(a[i]==b[j])
printf("%d\n",a[i]);
}
}

getch();
}