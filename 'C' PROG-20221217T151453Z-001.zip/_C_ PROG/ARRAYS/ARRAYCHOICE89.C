113.	PRESS �M� - MAXIMUM ,�N� - MINIMUM
	main()
	{
		int a[5],i,j,k;
		char ch;
		for (i = 0;i<5;i + +)
				{			
				 printf (�Enter the %d array elements = �,i);
			  scanf (�%d�,&a[i]);
			 }
		printf (�\n M - Minimum & N - Minimum�);
		printf (�\n Enter your choice = �);
		scanf (�%s�,&ch);

		if (( ch = = �m�) || ( ch = = �M�))
  			{
			 for (i = 0;i<5;i + +)
			    {
				for ( j = i + 1;j<5;j + +)
					{	
					if (a[ i ] > a[ j ] )
				       {
				         k = a [ i ];
				         a [ i ] = a [ j ];
				         a [ j ] = k;
					}
				    }
				 }
	 i = 4;
	 printf(�\n Maximum array element = %d�,a[i]);
	}

	else if (( ch = = �n�) || ( ch = = �N�))
		{
		 for (i = 0;i<5;i + +)
				{   
				for ( j = i + 1;j<5;j + +)
					{
					if (a[ i ] > a[ j ] )
					{				       
					k = a [ i ];
				       	a [ i ] = a [ j ];
				      	a [ j ] = k;
					}	
				    }
				}
	 i = 0;  
	 printf(�\n Minimum array element = %d�,a[i]);
	}
