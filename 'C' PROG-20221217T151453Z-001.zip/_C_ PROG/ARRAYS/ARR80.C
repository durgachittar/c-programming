
	#include<stdio.h>
	#include<conio.h>

	/*
		Array
		We can store number of elements(values) which has same data
		type.
		declaration
		<data type> <array name>[index]
		[] = subscript
		e.g
			int arr[5]
			arr[0] = 11
			arr[1] = 22
			arr[2] = 33
			arr[3] = 44
			arr[4] = 55
	*/

	void main()
	{
		int arr[5];
		int i;

		clrscr();
		for(i=0; i<5; i++)
		{
			printf("Enter the value of arr[%d] :",i);
			scanf("%d",&arr[i]);
		}

		printf("Array elements \n");
		for(i=0; i<5; i++)
		{
			printf("%d\n",arr[i]);
		}
	}