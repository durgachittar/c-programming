main()
{
int a[5],b[5],i;
clrscr();
printf("enter first array");
for(i=0;i<5;i++)
scanf("%d",&a[i]);
printf("enter second array");
for(i=0;i<5;i++)
scanf("%d",&b[i]);
printf("alternate array elements are");
for(i=0;i<5;i++)
printf("\n%d\n%d",a[i],b[i]);
getch();
}

