	#include<stdio.h>
	#include<conio.h>

	/*
		sizeof(expression)
		Returns the size, in bytes, of the given expression or type.
		expression - value ,data type,variable
	*/

	void main()
	{
		int i,arr[5],m[3][3];
		char ch,str[5];
		float f;

		clrscr();
		printf("Size of int i = %d byte\n",sizeof(i));
		printf("Size of int   = %d byte\n",sizeof(int));
		printf("Size of int 1 = %d byte\n",sizeof(1));

		printf("Size of float f  = %d byte\n",sizeof(f));
		printf("Size of float    = %d byte\n",sizeof(float));
		printf("Size of float 1.1= %d byte\n",sizeof(1.1));

		printf("Size of char ch= %d byte\n",sizeof(ch));
		printf("Size of char   = %d byte\n",sizeof(char));
		printf("Size of char a = %d byte\n",sizeof('a'));

		printf("Size of int arr = %d byte\n",sizeof(arr));
		printf("Size of char str= %d byte\n",sizeof(str));
		printf("Size of int m  = %d byte\n",sizeof(m));

	}
