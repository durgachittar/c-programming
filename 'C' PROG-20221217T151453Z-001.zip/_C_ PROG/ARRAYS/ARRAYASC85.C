	#include<stdio.h>
	#include<conio.h>

	void main()
	{
		int arr[5];
		int i,j;
		int temp;

		clrscr();
		for(i=0;i<5;i++)
		{
			printf("enter the arr ele[%d]:",i);
			scanf("%d",&arr[i]);
		}

		for(i=0; i<5; i++) //iteration
		{
			for(j=0; j<4; j++) //comparison
			{  \
				if(arr[j] > arr[j+1])
				{
					temp = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = temp;
				}
			}
		}

		printf("Sorted array in ascending order \n");


		for(i=0; i<5; i++)
		{
			printf("%d\n",arr[i]);
		}
	}