    main()
    {
    int a[2][3],i,j,num;
    clrscr();
    printf("enter 2*3 matrix:");
    for(i=0;i<2;i++)
    {
    for(j=0;j<3;j++)
    {
    scanf("%d",&a[i][j]);
    }
    }
    printf("\nEnter the number:");
    scanf("%d",&num);
    printf("Result matrix is:\n");
    for(i=0;i<2;i++)
    {
    for(j=0;j<3;j++)
    {
    printf("\t%d",a[i][j]*num);
    }
    printf("\n");
    }
    getch();
    }
