	#include<stdio.h>
	#include<conio.h>

	void main()
	{
		int arr[5];
		int i,num;
		int flag;

		clrscr();
		for(i=0; i<5; i++)
		{
			printf("Enter the value of arr[%d] :",i);
			scanf("%d",&arr[i]);
		}

		//12 23 34 45 56
		printf("Enter the number :");
		scanf("%d",&num);

		//90
		for(i=0; i<5; i++)
		{
			if(arr[i] == num)
			{
				flag = 1;
				break;
			}
		}

		if(flag == 1)
		{
			printf("Number is present at %d index",i);
		}
		else
		{
			printf("Number is not present");
		}
	}
