#include<stdio.h>
#include<conio.h>
#include<alloc.h>

#define MAX15
#define MAX27

int *arr;

int*create(int);
void sort(int*,int);
void display(int*,int);
int*merge(int*int);

void main()
{
int*a,*b,*c;
clrscr();
printf("\nenter the elements of first array:\n\n");
a=create(MAX1);

printf("\n enter elements for second array:\n\n");
b=create(MAX2);

sort(a,MAX1);
sort(b,MAX2);

printf("\nFirst array:\n");
display(a,MAX1);
printf("\n second array:\n");
display(b,MAX2);

c=merge(a,b);
display(c,MAX1+MAX2);

getch();
}
/*creates array of given size dynamicaly*/
int*create(int size)
{
 int*arr,i;
 arr=(int*)malloc(sizeof(int)*size);

 for(i=0;i<size;i++)
 {
 printf("enter the element no.%d",i+1);
 scanf("%d",&arr[i]);
 }
 return arr;
 }

 void sort(int*arr,int size)
 {
 int,temp,j;
 for(i=0;i<size;i++)
 {
 for(j=i+1;j<size;j++)
 {
 if(arr[i]>arr[j])
 {
  temp=arr[i];
  arr[i]=arr[j];
  arr[j]=temp;
  }
  }
  }
  }

  void display(int*arr,int size)
  {
  int i;
  for(i=0;i<size;i++)
  printf("%d",arr[i]);
  }

  int*merge(int*a,int*b)
  {
    int*arr;
    int,i,k,j;
    int size=MAX1+MAX2;
    arr=(int*)malloc(sizeof(int)*(size));

    for(k=0,j=0,i=0;i<=size;i++)
    {
     if(a[k]<b[j])
      {
      arr[i]=a[k];
      k++;
      if(k>=MAX)
      {
      for(i++;j<MAX2;j++,i++)
      arr[i]=b[j];
      }
      }
      else
      {
      arr[i]=b[j];
      j++;
      if(j>=MAX2)
      {
       for(i++;k<MAX1;k++,i++)
       arr[i]=a[k];
       }
       }
       }
       return arr;
       }