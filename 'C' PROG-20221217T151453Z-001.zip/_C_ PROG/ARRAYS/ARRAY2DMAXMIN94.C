#include<conio.h>
#include<stdio.h>
main()
{
int a[3][3],i,j,max,min;
clrscr();
printf("Enter the array elememt:");
for(i=0;i<3;i++)  //row
{
for(j=0;j<3;j++)  //col
{
scanf("%d",&a[i][j]);
}
}
max=a[0][0];
min=a[0][0];
for(i=0;i<3;i++)
{
for(j=0;j<3;j++)
{
if(a[i][j]>max)
max=a[i][j];
if(a[i][j]<min)
min=a[i][j];
}
}
printf("max number=%d\n min number=%d",max,min);
}