#include<stdio.h>
#include<conio.h>
void main()
{
int arr[5]={1,2,3,4,5};
int i;
clrscr();
printf("array elements:-");
for(i=0;i<5;i++)
{
printf("%d \n",arr[i]);
}
{
printf("reverse value \n");
for(i=4;i>=0;i--)
printf("%d \n",arr[i]) ;
}
getch();
}
