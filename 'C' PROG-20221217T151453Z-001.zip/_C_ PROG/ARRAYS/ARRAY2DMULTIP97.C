121.	MULTIPLICATION OF TWO 2D ARRAYS.
		main()
		{
			int a[3][3],b[3][3],i,j,mul,c[3][3],k,sum;
			printf ("Enter the 1st Matrix");
			printf ("\t Enter the 2nd Matrix");
			printf ("\t The Multipliction of two array");
			for (i = 0;i<3;i + +)
			      for (j = 0;j<3;j + +)
				       gotoxy ((3 x j) + 5,(3 x i) + 5);
					 scanf ("%d",&a[i][j]);
		
			for (i = 0;i<3;i + +)
			      for (j = 0;j<3;j + +)
					gotoxy ((3 x j) + 25,(3 x i) + 5);
					scanf ("%d",&b[i][j]);
			
			for (i = 0;i<3;i + +)
				for (j = 0;j<3;j + +)
					for (k = 0,c[i][j] = 0;k<3;k + +)
				            c[i][j] + = a[i][k] x b[k][j];
	
			for (i = 0;i<3;i + +)
				for (j = 0;j<3;j + +)
					gotoxy((3*j)+45,(3*i)+5);
					printf("%d",c[i][j]);
			}
