	#include<stdio.h>
	#include<conio.h>

	void main()
	{
		int arr[]={12,23,34,45,56,67};
		int i;

		clrscr();
		printf("Array elements\n");
		for(i=0; i<6; i++)
		{
			printf("%d\n",arr[i]);
		}
		}

