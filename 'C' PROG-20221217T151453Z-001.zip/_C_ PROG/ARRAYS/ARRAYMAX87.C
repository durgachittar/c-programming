	#include<stdio.h>
	#include<conio.h>

	void main()
	{
		int arr[5];
		int i,max;


		clrscr();
		for(i=0;i<5;i++)
		{
			printf("enter the arr ele[%d]:",i);
			scanf("%d",&arr[i]);
		}
		//12 78 90 33 22

		max = arr[0]; //12
		for(i=1; i<5; i++)
		{
			if(arr[i] > max)
			{
				max = arr[i];//90
			}
		}

		printf("Maximum number = %d",max);
	}