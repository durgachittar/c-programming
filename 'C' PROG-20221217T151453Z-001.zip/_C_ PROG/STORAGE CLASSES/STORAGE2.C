#include<stdio.h>
#include<conio.h>
  void main()
  {
	register int arr[5];
	int i;
	  clrscr();

	   for(i=0;i<5;i++)
	   {
		printf("Enter the value of arr[%d]:",i);
		scanf("%d",&arr[i]);
	    }

	    printf("Array elements\n");
	    for(i=0;i<5;i++)
	    {
		  printf("%d\n",arr[i]);
	    }
   }