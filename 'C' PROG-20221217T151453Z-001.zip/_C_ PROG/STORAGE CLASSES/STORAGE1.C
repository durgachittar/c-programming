#include<stdio.h>
#include<conio.h>
   void main()
   {
       auto int i=10;
       clrscr();
	   printf("Value of i=%d\n",i);
	   {
		auto int i=20;
		printf("Value of i=%d\n",i);
		{
			auto int i=29;
			printf("Value of i=%d\n",i);
		}
     //		printf("Value of i=%d\n",i);
	    }
	 //   printf("Value of i=%d\n",i);
    }
