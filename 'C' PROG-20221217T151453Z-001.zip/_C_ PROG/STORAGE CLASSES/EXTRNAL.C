		#include<stdio.h>
		#include<conio.h>

		/*
			Storage class
			External storage class(global variable)

			By default store zero value.
		*/
		int k=10;

		void fun()
		{
			printf("%d\t%d\t%d\t%d\n",k++,++k,k--,--k);
			//9 9 9 9
		}

		void main()
		{
			clrscr();
			/*
				1. increment
					1. pre increment
						++num;
						first increment the value and then execute operation
					2. post increment
						num++;
						first execute operation and then  increment the value
				2. decrement
					1. pre decrement
						--num;
						first decrement the value and then execute operation
					2. post decrement
						num--;
						first execute operation and then  decrement the value

			*/

			printf("k = %d\n",k++); //10 11
			printf("k = %d\n",++k); //12 12
			printf("k = %d\n",k--); //12 11
			printf("k = %d\n",--k); //10 10
			fun();
		}