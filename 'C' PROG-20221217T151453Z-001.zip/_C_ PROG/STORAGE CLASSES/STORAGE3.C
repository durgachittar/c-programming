#include<stdio.h>
#include<conio.h>
  void fun()
  {
	static int num1=19;
	static int num2=28;
	printf("num1=%d\tnum2=%d\t",num1,num2);

	num1++;
	num2++;
   }

   void main()
   {
	clrscr();
		fun();
		fun();
		fun();
   }