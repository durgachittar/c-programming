/*Program to create paranthesized expression from user & check whether it is well parenthesized or not */

#include<stdio.h>
#define MAX 100
struct stack
{
	int top;
	char item[MAX];
};
void initstack(struct stack*ps)
{
	ps->top=-1;
}
int isempty(struct stack*ps)
{
	return(ps->top=-1);
}
void push(struct stack*ps,int n)
{
	ps->item[++ps->top]=n;
}
int pop(struct stack*ps)
{
	int n;
	if(isempty(ps)!=1)
	{	
		n=ps->item[ps->top--];
		return(n);
	}
	else
	return 0;
}
main()
{
	void check(char exp[]);
	char exp[20];
	printf("\nEnter the Expression :");
	scanf("%s",exp);
	check(exp);
}
void check(char exp[])
{
	int i,flag1,flag2,flag3;
	char ch;
	struct stack s1;
	initstack(&s1);
	for(i=0;exp[i]!='\0';i++)
	{
		switch(exp[i])
		{
			case'{':push(&s1,exp[i]);
				break;
			case'(':push(&s1,exp[i]);
				break;
			case'[':push(&s1,exp[i]);
				break;
			case')':ch=pop(&s1);
				if((ch=='(')&&(ch!=0))
				flag1=1;
				else
				flag1=0;
				break;
			case'}':ch=pop(&s1);
                                if((ch=='{')&&(ch!=0))
                                flag2=1;
                                else
                                flag2=0;
                                break;
			case']':ch=pop(&s1);
                                if((ch=='[')&&(ch!=0))
                                flag3=1;
                                else
                                flag3=0;
                                break;
			default:
				break;
		}
	}
	if((flag1==1)||(flag2==1)||(flag3==1))
	printf("\n\nThe given expression is fully paranthesized\n");
	else
	printf("\nThe given expression is not fully paranthesized\n");
//	return 0;
}

