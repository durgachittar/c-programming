/*Program for Dynamic stack*/
#include<stdio.h>
#include<malloc.h>
struct node
{
   int data;
   struct node *next;
}*top;
typedef struct node *NODEPTR;
#define NODEALLOC (struct node*)malloc(sizeof(struct node))
void initstack()
{
   top=NULL;
}
int isempty()
{
   return(top==NULL);
}
void push(int n)
{
   NODEPTR newnode;
   newnode=NODEALLOC;
   newnode->next=NULL;
   newnode->data=n;
   if(top == NULL)
      top=newnode;
      else
       {
         newnode->next=top;
         top=newnode;
       }
}
   int pop()
   {
     int n;
     NODEPTR temp=top;
     n=top->data;
     top=top->next;
     free(temp);
     return(n);
   }
   int main()
   {
     int ch,n;
     initstack();
     do
      {
         printf("\n1:Push\n2:Pop\n3:Exit");
         printf("\nEnter your Choice:");
         scanf("%d",&ch);
         switch(ch)
          {
            case 1:
                    printf("\nEnter the Element to be Pushed:");
                    scanf("%d",&n);
                    push(n);
             break;
            case 2:
                    if(isempty()) 
                       printf("\nStack is empty");
                    else
                       printf("\nPopped element:%d",pop());
              break;
           }
        }
    while(ch!=3);
  return 0;
}
       
             


