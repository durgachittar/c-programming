/*Binary Search Tree levelwise */

#include<stdio.h>
#include<malloc.h>
#define MAX 40

typedef struct tree 
{
	int data;
	struct tree *left,*right;
}TREE;

typedef struct que
{
	TREE *datai[MAX];
	int front,rear;
}Q;

int isfull(Q *q)
{
	return(q->rear == MAX-1);
}

int isempty(Q *q)
{
	return(q->rear == q->front);
}

void addq(Q *q,TREE *n)
{
	if(!isfull(q))
		q->datai[++q->rear] = n;
	else
		printf("\nThe QUEUE is full.\n");
}

TREE *delq(Q *q)
{
	TREE *n;
	if(!isempty(q))
	{
		n=q->datai[++q->front];
		return(n);
	}
	else
		printf("\nThe QUEUE is empty.\n");
}

TREE *create(TREE *root)
{
	 TREE *newnode,*temp;
	 int n,i;
	 printf("\nEnter the total no of elements :");
	 scanf("%d",&n);
	 for(i=1;i<=n;i++)
	 {
		newnode=(TREE *)malloc(sizeof(TREE));
		newnode->left=newnode->right=NULL;
		printf("\nEnter the data items :");
		scanf("%d",&newnode->data);
		if(root==NULL)
		   root=newnode;
		else
		   {
			temp=root;
			while(1)
			{
				if(newnode->data<temp->data)
				{
					if(temp->left==NULL)
					{
						temp->left=newnode;
						break;
					}
					else
					temp=temp->left;
				}
				else
				if(newnode->data>temp->data)
				{
					if(temp->right==NULL)
					{
						temp->right=newnode;
						break;
					}
				}
				else
				temp=temp->right;
				break;
			}
		
	        }
         }return(root);
}

void initq(Q *q)
{
	q->front = q->rear = -1;
}

void display(TREE *root)
{
	Q *q;
	int level=0;
	TREE *temp=root,*dummy=NULL;
	initq(q);
	addq(q,temp);
	addq(q,dummy);
	printf("\nLEVEL:%d",level);
	do
	{
		temp=delq(q);
		if(temp!=dummy)
		printf("%d",temp->data);
		if(temp==dummy)
		{
			if(!isempty(q))
			{
				level++;
				printf("\nLEVEL%d",level);
				addq(q,dummy);
			}
		}
		else
		{
			if(temp->left)
				addq(q,temp->left);
			if(temp->right)
				addq(q,temp->right);
		}
	}
	while(!isempty(q));
	printf("\nThe height of the tree is :%d",level+1);
}

main()
{
	TREE *root;
	root=NULL;
	root=create(root);
	printf("\nLEVEL-WISE DISPLAY OF TREE.\n");
	display(root);
}
