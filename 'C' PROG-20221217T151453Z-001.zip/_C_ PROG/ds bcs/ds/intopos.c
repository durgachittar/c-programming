/* Infix to POstfix */

#include<stdio.h>
#define MAX 15
struct stack
{
	int item[MAX];
	int top;
};

void initstack(struct stack *ps)
{
	ps->top = -1;
}

int isempty(struct stack *ps)
{
	return(ps->top == -1);
}

int pop(struct stack *ps)
{
	return(ps->item[ps->top--]);
}

void push(struct stack *ps)
{
	ps->item[++ps->top]=n;
}

int main()
{
	void postfix(char in[],char post[]);
	char in[20],post[20];
	printf("\nEnter the fully parenthesized infix expression :");
	scanf("%s",in);
	postfix(in,post);
	printf("\n\nThe postfix string is :");
	printf("%s",post);
	return(0);
}

void postfix(char in[],char post[])
{	
	int i,j=0;
	char ch;
	struct stack s1;
	initstack(&s1);
	for(i=0;in[i]!='\0';i++)
	swtich(in[i])
	{
		case 'a':
		case 'b':
		case 'c':
		case 'd':post[j]=in[i];
		j++;
		case '+':
		case '-':
		case '*':
		case '/':
		case '%':
		case '(':push(&s1,in[i]);
			 break;
	        case ')':
		while((ch=pop(&s1))!='(')
		{
			post[j]=ch;
			j++;
		}
	}
}
	while(!isempty(&s1))
	{
		post[j]=pop(&s1);
		j++;
	}

	post[j]='\0';
}		
