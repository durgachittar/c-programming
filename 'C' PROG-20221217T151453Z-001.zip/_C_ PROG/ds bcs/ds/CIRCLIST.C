#include<stdio.h>
#include<conio.h>

typedef struct node
{
	int data;
	struct node *next;
}link;

link * create (link * f,int val) //it is use to return only one value i.e f
{
	link * temp;
	if (f == NULL)
	{
		f = (link *) malloc(sizeof (link));
		temp = f;
	}
	else
	{
		for(temp = f; temp->next != f ;temp = temp->next);// do nothing loop
		temp->next = (link *) malloc(sizeof (link));
		temp = temp->next;
	}
	temp->data= val;
	temp->next = f;
	return f;
}

void display(link *f)
{
	link *temp;
	temp=f;
	if(f!=NULL)
	{
		do
		{
			printf("%d \n",temp->data);
			temp = temp->next;
		}while(temp!=f);
	}
	else
		printf("\nList is empty");
}


int count(link *f)
{
	int i=0;
	link *s;
	s=f;
	do
	{
		i++;
		s = s->next;
	}while(s != f);
	return i;
}

link * insert(link *f)
{
	link *s,*t;
	int i,pos,max = count(f) + 1;
	printf("Enter the position :");
	scanf("%d",&pos);
	if(pos <= max)
	{
	if(pos == 1)
	{
		s = (link *) malloc(sizeof(link));
		for(t=f;t->next!=f;t=t->next);
		printf("Enter the value :");
		scanf("%d",&s->data);
		s->next = f;
		f = s;
		t->next=f;
	}
	else
	{
		for(i=1,s=f; i<pos -1;i++,s =s->next);
		t = s->next;
		s->next = (link *) malloc (sizeof(link *));
		s = s->next;
		printf("Enter the value :");
		scanf("%d",&(s->data));
		s->next = t;
	}
	}
	else
		printf("Max position is %d",max);
	return f;
}

link * delete(link *f)
{
	link *s,*t;
	int i,pos,max=count(f);
	printf("Enter the position :");
	scanf("%d",&pos);
	if(pos <= max)
	{

		if(pos==1)
		{
			s=f;
			for(t=f;t->next!=f;t=t->next);
			if(f==f->next)//if only one node
				f=NULL;
			else
				f=f->next;
			printf("Deleted data = %d",s->data);
			free(s);
			t->next=f;
		}
		else
		{
			for(i=1,s=f;i<pos-1;i++,s = s->next);//do nothing loop
			t =s->next->next ;
			printf("Deleted data = %d",s->next->data);
			free(s->next);
			s->next=t;
		}
	}
	else
		printf("\nList is empty");
	return f;
}

/*void disprev(link *f)
{
	link *t,*s;
	s=f;
	do
	{
		for(t=f;t->next!=s;t=t->next);
		printf("%d\n",t->data);
		s=t;
	}while(t!=f);
}

link * reverse(link *f)
{
	link *a,*b,*c=NULL;
	a=f;
	for(c=f;c->next!=f;c=c->next);
	do
	{
		b=a;
		a=a->next;
		b->next=c;
		c=b;
	}while(a!=f);
	return c;
}*/

void main()
{
	int ch,n;
	link *head = NULL;
	clrscr();
	do
	{
		printf("\n1.Add node");
		printf("\n2.Display");
		printf("\n3.clear");
		printf("\n4.count");
		printf("\n5.insert");
		printf("\n6.delete");
		printf("\n7.Exit");
		printf("\nEnter the chioce :");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				printf("Entert the number :");
				scanf("%d",&n);
				head = create(head,n);
				break;
			case 2:
				display(head);
				break;
			case 3:
				clrscr();
				break;
			case 4:
				printf("Number of nodes of list = %d",count(head));
				break;
			case 5:
				head = insert(head);
				break;
			case 6:
				head = delete(head);
				break;
		}
	}while(ch!=7);
}

