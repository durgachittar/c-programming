﻿/* To create hash table using static which display's overflow msg */

#include<stdio.h>
#include<conio.h>
#define size 10

typedef struct
{
	int rno;
	char name[15];
}stud;

void init(stud htab[])
{
	int i;
	for(i = 0; i<size; i++)
	{
		htab[i].rno = -1;
		strcpy(htab[i].name," ");
	}
}

int hash(int no)
{
		no = no % size +1; //modulo-division method
		if(no==10)
			no=0;
		return no;
}

int isfull(stud htab[])
{
	int i;
	for(i = 0; i<size; i++)
		if(htab[i].rno == -1)
			return 0;
	return 1;
}

void add(stud htab[])
{
	int i, no,j, cnt, k;
	if(!isfull(htab))
	{
		printf("\nEnter Rno ");
		scanf("%d", &no);
		i = hash(no);
		if(htab[i].rno != -1)// some stud data is already in that pos
		{
			j = hash(htab[i].rno);
			if(i != j) // prev data is at wrong pos
			{
				k = i;
				cnt = i;
				do
				{
					k= (k +1) % size;
				}while(htab[k].rno != -1 && k != cnt );
				if(k!= cnt)// new blank pos found for prev data
				{
					htab[k].rno = htab[i].rno;
					strcpy(htab[k].name, htab[i].name);

					htab[i].rno = no;
					printf("\nEnter Name ");
					flushall();
					gets(htab[i].name);
				}
			}
			else // prev data is at correct pos so find new pos for new data
			{
				cnt = i;
				do
				{
					i= (i +1) % size;
				}while(htab[i].rno != -1 && i != cnt );
				if(i != cnt)// new blank pos found for prev data
				{
					htab[i].rno = no;
					printf("\nEnter Name ");
						flushall();
					gets(htab[i].name);
				}
			}
		}
		else// pos is empty , add data directly
		{
			htab[i].rno = no;
			printf("\nEnter Name ");
			flushall();
			gets(htab[i].name);
		}
	}
	else
		printf("\n Table is full ");
}

void disp(stud htab[])
{
	int i;
	for(i=0;i<size;i++)
		printf("\n%d %s",htab[i].rno, htab[i].name);
}

int search(stud htab[],int no)
{
	int i,cnt;
	i = hash(no);
	if(htab[i].rno == no)
		return i;
	else
	{
		cnt = i;
		do
		{
			i= (i +1) % size;
		}while(htab[i].rno != no && i != cnt );

		if(i!= cnt)
			return i;
		else
			return -1;

	}
}
void del(stud htab[])
{
	int i, no;
	printf("\nEnter Rno to delete ");
	scanf("%d", &no);
	i = search(htab,no);
	if(i)
	{
		htab[i].rno = -1;
		strcpy(htab[i].name," ");
	}
	else
		printf("\n Rno %d is not found ", no);
}

void update(stud htab[])
{
	int i , cnt, no;
	printf("\nEnter Rno to update ");
	scanf("%d", &no);
	i = hash(no);
	if(htab[i].rno == no)
	{
		htab[i].rno = -1;
		add(htab);
	}
	else
	{
		cnt = i;
		do
		{
			i = (i +1) % size;
		}while(htab[i].rno != no && i != cnt );

		if(i != cnt)
		{
			htab[i].rno = -1;
			add(htab);
		}
		else
			printf("\n Rno %d not found ", no);
	}
}



void main()
{
	stud htab[size];
	int i, ch,no;

	init(htab);
	clrscr();
	do
	{

		printf("\n 1. Add a student  " );
		printf("\n 2. Search a student  ");
		printf("\n 3. Delete a student  ");
		printf("\n 4. Update a student  ");
		printf("\n 5. Dispaly all students  ");
		printf("\n 6. Clear Screen  ");
		printf("\n 7. Exit  ");
		printf("\n Enter your choice  ");
		scanf("%d", &ch);
		switch(ch)
		{
			case 1:
				add(htab);
				break;
			case 2:
				printf("\nEnter Rno to search ");
				scanf("%d", &no);

				i = search(htab,no);
				if(i>=0)
					printf("\n Rno = %d Name = %s", htab[i].rno, htab[i].name);
				else
					printf("\nRecord Not Found ");
				break;
			case 3:
				del(htab);
				break;
			case 4:
				update(htab);
				break;
			case 5:
				disp(htab);
				break;
			case 6:
				clrscr();
				break;
		}
	}while(ch != 7);
}