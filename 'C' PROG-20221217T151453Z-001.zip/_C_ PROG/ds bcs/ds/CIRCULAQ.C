#include<stdio.h>
#include<conio.h>
#define size 5

typedef struct
{
	int data[size];
	int front,rear;
}queue;

void init(queue *q)
{
	q->rear = size-1;
	q->front = size-1;
}

int isempty(queue *q)
{
	if(q->rear==q->front)
		return 1;
	else
		return 0;
}

int isfull(queue *q)
{
	if((q->rear+1) % size ==(q->front))
		return 1;
	else
		return 0;
}

void enqueue(queue *q,int val)
{
	if(!isfull(q))
	{
		q->rear = (q->rear + 1) % size;
		q->data[q->rear] = val;
	}
	else
	{
		printf("\nQueue is full");
	}
}

int dequeue(queue *q)
{
	if(!isempty(q))
	{
		q->front = (q->front + 1) % size;
		return q->data[q->front];
	}
	else
	{
		printf("\nQueue is empty");
		return 0;
	}
}

void disp(queue *q)
{
	int i=(q->front+1) % size;
	do
	{
		printf("%d\n",q->data[i]);
		i= (i+1)%size ;
	}while(i!=(q->rear+1)%size);
}


void main()
{
	int n,ch;
	queue q;
	init(&q);
	clrscr();
	do
	{
		printf("\n1.Add Element in queue\n");
		printf("2.Delete Element from queue\n");
		printf("3.Clear\n");
		printf("4.Display\n");
		printf("5.Exit\n");
		printf("Enter the choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				printf("Enter Data :");
				scanf("%d",&n);
				enqueue(&q,n);
				break;
			case 2:
				n=dequeue(&q);
				printf("\nDeleted data is %d",n);
				break;
			case 3:
				clrscr();
				break;
			case 4:
				disp(&q);
				break;
		}
	}while(ch!=5);
}