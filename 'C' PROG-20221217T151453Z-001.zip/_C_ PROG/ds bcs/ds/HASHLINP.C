#include<stdio.h>


    int hashfunc(int i)
	{
	   return i%10;
	   }


     void add(int ht[],int id)
	{
	     int pos,i;
	     pos=hashfunc(id);
	     if(ht[pos]==-1)
	       {
		     ht[pos]=id;
		     return;

		    }
		     else
		       for(i!=pos;i=pos+1;i=(i+1)%10)
		     {
			 if(ht[i]==-1)
			  {
			    ht[i]=id;
			    return;
			   }
		     }
	     if(i==pos)
		printf("\n hash table full");
	    }



       void delete(int ht[],int id)
	 {
	    int pos,i;
	    pos=hashfunc(id);
	    if(ht[pos]==id)
	      {
		ht[pos]=-1;
		 return;
		  for( i!=pos;i=pos+1;i=(i+1)%10)
		    {
			if(ht[i]==id)
			  {
			      ht[i]=-1;
			      return;
			    }
		       }
		   if(i==pos)
		    printf("\nindentifer not found");
		}


    void display(int ht[])
       {
	   int i;
	   printf("\nbucket\tindentifer\n");
	   for(i=0;i<10;i++)
	   if(ht[i]==-1)
	   printf("%d\t\tempty\n",i);
	      else
		  printf("%d\t\t%d\n",ht[i]);
	      }


       int main()
	{
	   int ht[10]={-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},n,choice;
	do
	   {
	     printf("\n1:ADD\n2:DELETE\n3:DISPLAY\n4:EXIT");
	     printf("\nenter ur choice:");
	     scanf("%d",&choice);
	     switch(choice)
		{
		   case 1:printf("\nenter the identifer:");
			   scanf("%d",&n);
			   add(ht,n);
			     break;

		   case 2:printf("\nenter the identifer:");
			  scanf("%d",&n);
			  delete(ht,n);
			   break;

		   case 3:
			    display(ht);
		  }
	      }while(choice!=4);
		  return 0;
	   }