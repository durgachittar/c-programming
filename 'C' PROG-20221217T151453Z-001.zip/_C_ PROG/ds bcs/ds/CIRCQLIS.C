#include<stdio.h>
#include<malloc.h>

typedef struct node
{
	int data;
	struct node *next;
}qnode;

typedef struct
{
	qnode *front;
	qnode *rear;
}queue;

void init(queue *q)
{
	q->rear = NULL;
	q->front = NULL;
}

int isempty(queue *q)
{
	if(q->front==NULL)
		return 1;
	else
		return 0;
}

int isfull(qnode *q)
{
	if(q==NULL)
		return 1;
	else
		return 0;
}

void enqueue(queue *q,int val)
{
	qnode *temp;
	temp = (qnode *)malloc(sizeof(qnode));
	if(!isfull(temp))
	{
		if(isempty(q))// for first node
			q->rear = q->front = temp;
		else
		{
			q->rear->next=temp;
			q->rear=temp;
		}
		temp->data=val;
		temp->next=q->front;
	}
	else
		printf("\nEmpty");
}

int dequeue(queue *q)
{
	qnode *temp;
	int r=0;
	if(!isempty(q))
	{
		temp = q->front;

		if(q->front->next == q->front )// true when only one node
			q->front=NULL;
		else
			q->front=q->front->next;

		q->rear->next = q->front;
		r=temp->data;
		free(temp);
	}
	else
		printf("\nEmpty");
	return r;
}

void freelist(queue *q)
{
	qnode *temp;
	while(!isempty(q))
	{
		temp=q->front;
		q->front=temp->next;
		free(temp);
	}
}

void disp(queue *q)
{
	qnode *temp,*s;
	temp=q->front;
	if(!isempty(q))
	{
		do
		{
			printf("\n%d",temp->data);
			temp=temp->next;
		}while(temp!=q->front);
	}
	else
		printf("\nEmpty");
}


void main()
{
	int ch,val;
	queue q;
	init(&q);
	clrscr();
	do
	{
		printf("\n1.Add node in queue\n");
		printf("2.Remove node from queue\n");
		printf("3.display\n");
		printf("4.Clear\n");
		printf("\n5.Exit");
		printf("\nEnter the choice");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				printf("Enter the value:");
				scanf("%d",&val);
				enqueue(&q,val);
				break;
			case 2:
				printf("Removed string is %d",dequeue(&q));
				break;
			case 3:
				disp(&q);
				break;
			case 4:
				clrscr();
				break;
		}
	} while(ch != 5);
	freelist(&q);
	disp(&q);
}
