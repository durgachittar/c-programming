/*Program for Depth First Search of Graph */
#include<stdio.h>
struct stack
{
   int data[20];
   int top;
}s1;
void push(int n)
{
   s1.data[++s1.top]=n;
}
int pop()
{
  return s1.data[s1.top--];
}
void initstack()
{
  s1.top=-1;
}
   int emptystack()
   {
      return(s1.top==-1);
   }
void dfs(int m[10][10],int n)
 {
   int i,v,w;
   int visited[20]={0};
   initstack();
   v=0;
   visited[v]=1;
   printf("%d\t",v+1);
   push(v);
   while(1)
   {
     for(w=0;w<n;w++)
      {
        if((m[v][w]==1)&&(visited[w]==0)) 
         {
           push(w);
           printf("%d\t",w+1);
           visited[w]=1;
         }
      }
  if(emptystack())
      break;
  else
     v=pop();
   }
 }
void recdfs(int m[10][10],int n,int v)
{
   int w;
   static int visited[20]={0};
   visited[v]=1;
   printf("%d\t",v+1);
   for(w=0;w<n;w++)
   {
     if((m[v][w]==1)&&(visited[w]==0))
     {
       recdfs(m,n,w);
     }
   }
}
int main()
{
   int m[10][10],n,i,j;
   printf("\nHow many vertices:");
   scanf("%d",&n);
   for(i=0;i<n;i++)
   for(j=0;j<n;j++)
   {
      if(i!=j)
      {
        printf("Is There an Edge between vertex %d and %d (1/0):",i+1,j+1);
        scanf("%d",&m[i][j]);
      }
   }
printf("\nThe Non Recursive Depth first Search is :");
dfs(m,n);
printf("\nThe Recursive Depth First Search is :");
recdfs(m,n,0);
return 0;
}
  
