/*Program for bestfit method */

#include<stdio.h>
#include<stdlib.h>
typedef struct node
{
	int data;
	struct node *next,*prev;
}node;

node *createlist(node *,int mem[]);
void bestfit(node *,int job[],int );

main()
{
	int n,i,job[20],mem[5]={50,100,75,250,200};
	node *head;
	head=(node *)malloc(sizeof(node));
	head->prev=NULL;
	head->next=NULL;
	printf("\nEnter the total no. of jobs: ");
	scanf("%d",&n);
	
		for(i=0;i<n;i++)
		{
			printf("\nEnter the memory requirement of job%d:",i+1);
			scanf("%d",&job[i]);
		}
		head=createlist(head,mem);
		bestfit(head,job,n);
}

node *createlist(node *head,int mem[5])
{
	int i,j;
	node *last,*new;
	last=head;
	for(i=0;i<5;i++)
	{
		new=(node *)malloc(sizeof(node));
		new->prev=NULL;
		new->next=NULL;
		new->data=mem[i];
		last->next=new;
		new->prev=last;
		last=new;
	}
	return(head);
}	

void bestfit(node *head,int job[20],int n)
{
	int i,req=0,flag=0;
	node *temp;
	printf("\n\n\t BEST FIT \n\n");
	printf("\nJOB");
	printf("\nRequest");
	
	for(i=0;i<n;i++)
	{
		flag=0;
		for(temp=head->next;temp!=NULL;temp=temp->next)
		{
			if(temp->data>=job[i])
			{
				req=temp->data;
				for(temp=temp->next;temp!=NULL;temp=temp->next)
				{
					if((temp->data>=job[i]) && (temp->data<req))
					req=temp->data;
				}
				for(temp=head->next;temp!=NULL;temp=temp->next)
				{
					if(temp->data==req)
					{
						temp->data=temp->data-job[i];
						if(temp->data==0)
						{
							if(temp->next!=NULL)
							temp->next->prev=temp->prev;
							temp->prev->next=temp->next;
						}	
						flag=0;
						break;
					}
				}
				if(flag==1)
				break;
			}
			printf("\n%-3d\t",job[i]);
			if((req==0)||(flag==0))
				printf("\tMEMORY UNAVAILABLE");
			else
			{
				for(temp=head->next;temp!=NULL;temp=temp->next)
				printf("%d\t",temp->data);
			}
		}
       		printf("\n");
	}
}

