/* Program for first fit method */

#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
	int size;
	int no;
	struct node *next;
}NODE;

NODE*getnode()
{
	NODE *newn;
        newn=(NODE*)malloc(sizeof(NODE));
	newn->next=NULL;
	return newn;
}

NODE*create()
{
	NODE*head=NULL,*temp,*newn;
	int i,n;
	printf("\nEnter how many blocks :");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		newn=getnode();
		printf("\nEnter size:");
		scanf("%d",&newn->size);
		newn->no=i;
		if(head==NULL)
		{
			head=temp=newn;
		}
		else
		{
			temp->next=newn;
			temp=newn;
		}
	}		
		return head;
}

void disp(NODE*first)
{
	NODE*temp=first;
	while(temp!=NULL)
	{
		printf("\n%d",temp->size);	
		temp=temp->next;
	}
}

void firstfit(NODE *list1,NODE *list2)
{
	NODE *temp=list2,*temp1=list1;
	int num,flag=0;
	while(temp!=NULL)
	{
		num=temp->size;
		while(temp1!=NULL)
		{
			if(num<=temp1->size)
			{
				temp1->size-=num;
				flag=1;
				break;
			}
			else
			temp1=temp1->next;
		}
		if(flag==0)
		printf("Request cannot be satisfied for %d",temp->no);
		temp=temp->next;
		flag=0;
	}
}
main()
{
	NODE*list1,*list2;
	int req,i;
	printf("\nEnter free block details :");
	list1=create();
	printf("\nEnter request details:");
	list2=create();
	printf("\nFREE LIST");
	disp(list1);
	printf("\nREQUEST LIST");
	disp(list2);
	firstfit(list1,list2);
	disp(list1);
}

