/*Program for Positive and Negative list*/
#include<stdio.h>
#include<malloc.h>
struct lists
{
   int data;
   struct lists*next;
};
typedef struct lists*PTR;
PTR temp1,temp2,pos,neg,node;
int main()
{
    int ch;
    pos=NULL;
    neg=NULL;
    do
     {
        node=(struct lists*)malloc(sizeof(struct lists));
        node->next=NULL;
        printf("Enter the Number:");
        scanf("%d",&node->data);
        if(node->data>0)
         {
            if(pos==NULL)
              pos=temp1=node;
              else
               {
                   temp1->next=node;
                   temp1=node;
               }
          }
        if(node->data<0)
         {
            if(neg==NULL)
              neg=temp2=node;
              else
               {
                  temp2->next=node;
                  temp2=node;
               }
          }
        printf("\nDo u want to Continue (1/0):");
        scanf("%d",&ch);
     }
   while(ch!=0);
     {
          printf("The Positive List is:");
          for(temp1=pos;temp1!=NULL;temp1=temp1->next)
           {
             printf("%d",temp1->data);
           }
             printf("\nThe Negative List is:");
              for(temp2=neg;temp2!=NULL;temp2=temp2->next)
               {
                 printf("%d",temp2->data);
               }
 return 0;
      }
}



   Output:
 [wasifa@localhost ~]$ ./a.out

Enter the Number:3

Do u want to Continue (1/0):1

Enter the Number:4

Do u want to Continue (1/0):1

Enter the Number:5

Do u want to Continue (1/0):1

Enter the Number:-6

Do u want to Continue (1/0):1

Enter the Number:-4

Do u want to Continue (1/0):1

Enter the Number:-3

Do u want to Continue (1/0):0

The Positive List is: 3  4  5
The Negative List is:-6 -4 -3 
