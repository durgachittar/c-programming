#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>
struct node
{
   int data;
   struct nod *next,*prev;
};
void create(struct node*list)
{
  int n,i;
  struct node *newnode,*temp;
  printf("\nHow many nodes:");
  scanf("%d",&n);
  for(i=1;i<=n;i++)
    {
      newnode=(struct node*)malloc(sizeof(struct node));
      scanf("%d",&n);
      if(list->next==list)
       {
         list->next=newnode;
         newnode->prev=list;
       }
      else
       {
         temp->next=newnode;
         newnode->prev=temp;
       }
         temp=newnode;
         list->prev=newnode;
         newnode->next=list;
     }
   }
  void insert(struct node *list ,int n, int pos)
    {
       struct node *temp=list->next,*newnode, *temp1;
       int i;
       newnode=(struct node *)malloc(sizeof(struct node));
       newnode->data=n;
       for(i=1,temp=list;(i<=pos-1) && (temp->next!=list);i++)
       temp=temp->next;
       if(temp->next==list)
         {
           printf("Position out of range\n");
           return;
        temp1=temp->next;
        newnode->next=temp1;
        temp1->prev=newnode;
        temp->next=newnode;
        newnode->prev=temp;
  void display(struct node*list)
   {
     struct node*temp;
     for(temp=list->next;temp!=list;temp->next)
     printf("%d\t",temp->data);
  void delete(struct node*list,int pos)
   {
     struct node *temp,*temp1,*temp2;
     int i;
     for(i=1,temp=list->next;(i<=pos-1) && (temp!=list); i++)
     temp=temp->next;
     if(temp==list)
       {
         printf("Position out of range");
         
     if("temp->next==list")    
      {

        free(temp);
        list->next=list;
         return;
    temp1=temp->prev;
    temp2=temp->next;
    temp1->next=temp2;
    temp2->prev=temp1;
    free(temp);
 void main()
   {
     struct node *list;
     int n,pos,choice;
     list=(struct node *)malloc(sizeof(struct node));
     list->next=list;
     do
     {
       printf("\n1: Create");
       printf("\n1: Insert");
       printf("\n1: Delete");
       printf("\n1: Display");
       printf("\n1: Exit");
       printf("\n\nEnter yur choice :");
       scanf("%d",&choice);
       switch(choice)
         {
            case 1:  
                   create(list);
                   display(list);
                   break;
            case 2:
                   printf("\nEnter the Element and Position");
                   scanf("%d%d",&n,&pos);
                   insert(list,n,pos);
                   display(list);
                   break;
            case 3:
                   printf("\nEnter the Position");
                   scanf("%d",&pos);
                   delete(list,pos);
                   display(list);
                   break;
            case 4:
                   display(list);
                   break;
         }
       }
     while(choice !=5);

}     



         
        

