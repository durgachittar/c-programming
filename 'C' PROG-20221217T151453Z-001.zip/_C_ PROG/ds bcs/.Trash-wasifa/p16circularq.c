/*Program for circular Queue*/
#include<stdio.h>
#define MAX 100
struct q
{
  int items[MAX];
  int front,rear;
};
void initq(struct q *pq)
{
  pq->front=pq->rear=MAX-1;
}
int isemptyq(struct q *pq)
{
  return(pq->front=pq->rear);
}
int isfullq(struct q *pq)
{
  return((pq->rear+1)%MAX==pq->front);
}
void addq(struct q *pq,int ch1)
{
   if(!isfullq(pq))
    {
      pq->rear=(pq->rear+1)%MAX;
      pq->items[pq->rear]=ch1;
    }
    else
    printf("\nQueue is full");
}
int delq(struct q *pq)
{
   pq->front=(pq->front+1)%MAX;
   return pq->items[pq->front];
}
int main()
{
  int n,ch;
  struct q q1;
  initq(&q1);
  do
   {
     printf("\n1:Add\n2:Delete\n3:Exit\n");
     printf("\nEnter ur Choice:");
     scanf("%d",&ch);
     switch(ch)
       {
     
          case 1:  
                   printf("Enter the element to be Added:");
                   scanf("%d",&n);
                   addq(&q1,n);
            break;
          case 2:
                   if(isemptyq(&q1)==1)
                   printf("\nQueue is Empty");
                   else
                   printf("\nThe Deleted element is:%d",delq(&q1));
            break;
       }
   }
   while(ch!=3);
   return 0;
}



 Output:
 [wasifa@localhost ~]$ ./a.out

1:Add
2:Delete
3:Exit

Enter ur Choice:1
Enter the element to be Added:8

1:Add
2:Delete
3:Exit

Enter ur Choice:2

The Deleted element is:8
1:Add
2:Delete
3:Exit

Enter ur Choice:3




