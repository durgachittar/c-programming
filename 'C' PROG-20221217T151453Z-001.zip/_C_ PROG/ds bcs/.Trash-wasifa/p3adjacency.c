/*Program for Adjacency Matrix of list*/
#include<stdio.h>
#include<malloc.h>
struct node
{
   int vertex;
   struct node *next;
}*v[10];
void createmat(int m[10][10],int n)
{
   int i,j;
   char ans;
   for(i=0;i<n;i++)
   for(j=0;j<n;j++)
   {
     m[i][j]=0;
     if(i!=j)
     {
       printf("\nIs there an edge between %d and %d(1/0):",i+1,j+1);
       scanf("%d",&m[i][j]);
     }
   }
}
void dispmat(int m[10][10],int n)
{
   int i,j;
   printf("\nThe Adjacency matrix:\n");
   for(i=0;i<n;i++)
   {
     for(j=0;j<n;j++)
     printf("%5d",m[i][j]);
     printf("\n");
   }
}
void createlist(int m[10][10],int n)
{
  int i,j;
  struct node *temp,*newnode;
  for(i=0;i<n;i++)
  {
    v[i]=NULL;
    for(j=0;j<n;j++)
    {
       if(m[i][j]==1)
        {
           newnode=(struct node *)malloc(sizeof(struct node));
           newnode->next=NULL;
           newnode->vertex=j+1;
           if(v[i]==NULL)
           v[i]=temp=newnode;
             else
              {  
                temp->next=newnode;
                temp=newnode;
              } 
         }
    }  
  }
}
void displist(int n)

{
   struct node *temp;
   int i;
   for(i=0;i<n;i++)
   {
      printf("\nv%d->",i+1);
      temp=v[i];
      while(temp)
       {
         printf("\nv%d->",temp->vertex);
         temp=temp->next;
       }     

   }
}
int main()
{
  int m[10][10],n;
  printf("\nEnter the number of Vertices:");
  scanf("%d",&n);
  createmat(m,n);
  dispmat(m,n);
  createlist(m,n);
  displist(n);
  return 0;
}   



   Output:
[wasifa@localhost ~]$ ./a.out

Enter the number of Vertices:3

Is there an edge between 1 and 2(1/0):1

Is there an edge between 1 and 3(1/0):0

Is there an edge between 2 and 1(1/0):1

Is there an edge between 2 and 3(1/0):0

Is there an edge between 3 and 1(1/0):1

Is there an edge between 3 and 2(1/0):1

The Adjacency matrix:
    0    1    0
    1    0    0
    1    1    0

v1->
v2->
v2->
v1->
v3->
v1->
v2->

