/*Program fo creating union of two lists*/
#include<stdio.h>
#include<stdlib.h>
struct node
{
   int data;
  struct node *next;
}*
start=NULL,*start1=NULL,*start2=NULL,*start3=NULL,*temp,*temp1,*temp2,*temp3,*t,*t1,*t2,*q,*r,*s;
void create1(int n)
{
  int i=0;
  printf("\nEnter %d Elements",n);
  while(i<n)
 {
  struct node*newnode;
  newnode=(struct node*)malloc(sizeof(struct node));
  newnode->next=NULL;
  if(start1==NULL)
     temp=start1=newnode;
  else
    {
      temp1->next=newnode;
      temp1=newnode;
    }
  scanf("%d",&temp1->data);
  i++;
 }
}
void create2(int m)
{
  int i=0;
  printf("\n Enter Elements:",m);
  while(i<m)
 {
   struct node*newnode;
   newnode=(struct node*)malloc(sizeof(struct node));
   newnode->next=NULL;
   if(start2==NULL)
    temp2=start2=newnode;
   else
    {
      temp2->next=newnode;
      temp2=newnode;
    }
  scanf("%d",&temp2->data);
  i++;
 }
}
void uni(struct node *start1,struct node*start2,struct node*start3)
{
  int c=0,i;
  temp3=start3;
  temp1=start1;
  while(temp1!=NULL)
   {
     struct node*newnode;
     newnode=(struct node*)malloc(sizeof(struct node));
     newnode->next=NULL;
     if(start3==NULL)
      temp3=start3=newnode;
     else
       {
         temp3->next=newnode;
         temp3=newnode;
       }
       temp3->data=temp1->data;
       temp1=temp1->next;
   }
   temp2=start2;
   while(temp2!=NULL)
    {
      temp1=start;
      c=0;
      while(temp1!=NULL)
       {
         if(temp2->data==temp1->data)       
          {
            c++;
            temp1=temp1->next;
          }
          else
            temp1=temp1->next;
       }
       if(c>0)
         {
            temp2=temp2->next;
         }
       else
         {
           struct node*newnode;
           newnode=(struct node*)malloc(sizeof(struct node));
           newnode->next=NULL;
         if(start3==NULL)
            temp3->next=start3=newnode;
         else
          { 
            temp3->next=newnode;
            temp3=newnode;
          }
          temp3->data=temp2->data;
          temp2=temp2->next;
         }
       }
          temp3=start3;
          for(temp3=start3;temp3!=NULL;temp3=temp3->next)
            {
              for(r=temp3;r!=NULL;r=r->next)
                {
                   if(temp3->data>r->data)
                    {
                      i=temp3->data;
                      temp3->data=r->data;
                      r->data=1;
                    }
                 }
            }
             temp3=start3;
             while(temp3!=NULL)
              {
                 printf("\t%d",temp3->data);
                 temp3=temp3->next;
              }
           }
          void display();
          main()
           {
             int n,m;
             printf("\nEnter how many elements in list 1:");
             scanf("%d",&n);
             create1(n);
             printf("\nEnter how many elements in list 2:");
             scanf("%d",&m);
             create2(m);
             printf("\nThe Union is :\n\n\n");
             uni(start1,start2,start3);
             display();
           }
          void display()
           {
             r=start3;
             if(start3!=NULL)
              {
                 printf("\nThe Union List is:");
                 while(r!=NULL)
                  {
                    printf("\n\t%d",r->data);
                    r=r->next;
                  }
               }
}


                 
           

    

  
   
