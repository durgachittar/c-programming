/*Program for chaining using linked list*/
#include<stdio.h>
#include<malloc.h>
struct node
{
   int ident;
   struct node *next;
}*ht[10];
int hashfunc(int n)
{
   return n%10;
}
void initialize()
{
   int i;
   for (i=0;i<10;i++)
   ht[i]=NULL;
}
void add(int id)
{
   struct node *newnode,*temp;
   int bucket;
   bucket=hashfunc(id);
   newnode=(struct node *)malloc(sizeof(struct node));
   newnode->ident=id;
   newnode->next=NULL;
   if(ht[bucket]==NULL)
      ht[bucket]=newnode;
   else
     {
       for(temp=ht[bucket];temp->next!=NULL;temp=temp->next)
           temp->next=newnode;
     }
     return;
}
void delete(int id)
{
  int bucket;
  struct node *temp,*temp1;
  bucket=hashfunc(id);
  temp=temp1=ht[bucket];
  if(temp->ident==id)
    {
      ht[bucket]=temp->next;
      free(temp);
      return ;
    }
  while(temp!=NULL)
     {
        if(temp->ident==id)
          {
             temp1->next=temp->next;
             free(temp);
             return;
          }
        temp1=temp;
        temp=temp->next;
     }
  printf("\nIdentifier not found");
}
void display()
{
  struct node *temp;
  int i;
  for(i=0;i<10;i++);
    {
      printf("\nBucket %d\t",i);
      for(temp=ht[i];temp!=NULL;temp=temp->next)
          printf("->%d",temp->ident);
    }  
}
int main()
{
   int n,ch;
   initialize();
   do
    {
      printf("\n1:ADD\n2:DELETE\n3:DISPLAY\n4:EXIT\n");
      printf("\nEnter Your Choice:");
      scanf("%d",&ch);
      switch(ch)
        {
             case 1:
                    printf("\nEnter the identifier:");
                    scanf("%d",&n);
                    add(n);
                    display();
                break;
             case 2:
                    printf("Enter the identifier:");
                    scanf("%d",&n);
                    delete(n);
                    display();
                break;
             case 3:
                    display();
         }            
    }
   while(ch!=4);
   return 0;
}
   

  Output:
[wasifa@localhost ~]$ ./a.out

1:ADD
2:DELETE
3:DISPLAY
4:EXIT

Enter Your Choice:1

Enter the identifier for Adding:6

Bucket 10
1:ADD
2:DELETE
3:DISPLAY
4:EXIT

Enter Your Choice:2

Enter the identifier for Deleting:6

Bucket 10
1:ADD
2:DELETE
3:DISPLAY
4:EXIT

Enter Your Choice:3

Bucket 10
1:ADD
2:DELETE
3:DISPLAY
4:EXIT

Enter Your Choice:4





