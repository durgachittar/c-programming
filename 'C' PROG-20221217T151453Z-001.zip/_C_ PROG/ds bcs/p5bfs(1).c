/*Program for BFS of graph*/
  #include<stdio.h>
  struct q
  {
     int data[20];
     int front,rear;
  }q1;
     void add(int n)
      {
        q1.rear++;
        q1.data[q1.rear]=n;
      } 
     int del()
      {
       q1.front++;
       return q1.data[q1.front];
      }
     void initq()
      {
       q1.front=q1.rear=-1;
      }
     int emptyq()
      {
       return(q1.rear==q1.front);
      }
    void bsf(int m[10][10],int n)
      {
        int i,j,v,w;
        int visited[20];
        initq();
          for(i=0;i<n;i++)
           visited[i]=0;
           printf("\nthe Breadth First Search is:\n");
           v=0;
           visited[v]=1;
           add(v);
              while(!emptyq()) 
                {
                   v=del();
                   printf("v%d",v+1);
              for(w=0;w<n;w++)
                  { 
                     if((m[v][w]==1)&&(visited[w]==0))
                       {    
                         add(w);
                         visited[w]=1;
                       }  
                  }
     
                } 
         
        }
      int main()
      {
        int m[10][10],n,i,j;
        void bfs(int m[10][10],int n);
        {
           printf("\nHow Many Vertices:");
           scanf("%d",&n);
           for(i=0;i<n;i++)
             for(j=0;j<n;j++)
             {
               if(i!=j)
         {
           printf("\nIs there an edge between vertex %d and %d (1/0):",i+1,j+1);
                 scanf("%d",&m[i][j]);
         }
        }
        bsf(m,n);
      return 0;
       }
      }

