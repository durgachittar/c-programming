/*Program to convert an Infix Expression to Postfix Expression for any number of variables*/

#include<stdio.h>
#define MAX 15
struct stack
{
      int item[MAX];
      int top;
};
void initstack(struct stack *ps)
{
  ps->top=-1;
}
int isempty(struct stack *ps)
{
return(ps->item[ps->top--]);
}
void push(struct stack *ps,int n)
{
  ps->item[++ps->top]=n;
}
int main()
{
   void postfix(char in[],char post[]);
   char in[20],post[20];
   printf("\nEnter fully Parenthesised infix expression:");
   scanf("%s",&in);
   fflush(stdin);
   postfix(in,post);
   printf("\nThe Postfix String is:");
   printf("%s",post);
}
void postfix(char in[],char post[])
{
   int j=0,i;
   char ch;
   struct stack s1;
   initstack(&s1);
   for(i=0;in[i]!='\0';i++)
    {
      switch(in[i])
       {
         case 'a':
         case 'b':
         case 'c':
         case 'd':
                  post[j]=in[i];
                  j++;
                  break;
         case '+':
         case '-':
         case '*':
         case '/':
         case '%':
         case '(':
                  push(&s1,in[i]);
                  break;
         case ')':
         while((ch=pop(&s1))!='(')
          {
            post[j]=ch;
            j++;
          }
       }
    }
while(!isempty(&s1))
 {
   post[j]=pop(&s1);
   j++;
 }
   post[j]='\0';
 return 0;
}

