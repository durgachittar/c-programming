#include<stdio.h>
#include<conio.h>
void area(int,int);
void main()
{
int l,b;
clrscr();
printf(" \n value of l & b:");
scanf("%d%d",&l,&b);
area(l,b);
getch();
}
void area(int l,int b)
{
float a;
a=l*b;
printf("\n area of rectangle=%f",a);
}

