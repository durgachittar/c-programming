     main()
     {
     clrscr();
     sum();
     sum();
     getch();
     }
     sum()
     {
     int num1,num2,s;
     printf("\n\nEnter two numbers:");
     scanf("%d%d",&num1,&num2);
     s=num1+num2;
     printf("\nSum is %d",s);
     }