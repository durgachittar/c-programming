#include<stdio.h>
#include<conio.h>
void square(int);       //function prototype
void main()
{
int a;
clrscr();
printf("\n value of a");
scanf("%d",&a);
square(a);              //call
getch();
}
void square(int a)
{
int s;
s=a*a;
printf("\nsquare=%d",s);
}


































