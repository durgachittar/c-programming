#include<stdio.h>
#include<conio.h>
void fibonacci(int);
void main()
{
int num;
clrscr();
printf("\n Enter the number:");
scanf("%d",&num);
fibonacci(num);
getch();
}
void fibonacci(int num)
{
int a,b,c;
a=0;
b=1;
c=0;
while(c<=num)
{
printf("%d\t",c);
a=b;
b=c;
c=a+b;
}
}