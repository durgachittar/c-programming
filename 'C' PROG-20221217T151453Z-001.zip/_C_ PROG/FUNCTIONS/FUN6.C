  #include<stdio.h>
  #include<conio.h>
void area(int);
void main()
{
int r;
clrscr();
printf("\n value of radius:");
scanf("%d",&r);
area(r);
getch();
}
void area(int r)
{
float a;
a=3.14*r*r;
printf("\n area of circle=%f",a);
}