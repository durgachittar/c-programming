#include<stdio.h>
#include<conio.h>

void cube(int);
void main()
{
int a;
clrscr();
printf("\n value of a:");
scanf("%d",&a);
cube(a);             //call
getch();
}
void cube(int a)
{
int c;
c=a*a*a;
printf("\n value of a=%d\t cube=%d",a,c);
}