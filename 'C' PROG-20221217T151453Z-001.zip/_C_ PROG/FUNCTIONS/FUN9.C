#include<stdio.h>
#include<conio.h>
mul (int,int);
void main()
{
 int i,j,x;
 clrscr();
 printf("enter the num:-\n");
 scanf("%d%d",&i,&j);
 x=mul(i,j);
 printf("%d",x);
 getch();
}
 mul(int i,int j)
 {
 if(j==1)
 {
 return(i);
 }
 else
 {
  return(i+mul(i,j-1));
  }
  }



