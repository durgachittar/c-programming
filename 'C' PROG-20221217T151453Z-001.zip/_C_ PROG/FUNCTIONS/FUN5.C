#include<stdio.h>
#include<conio.h>
void fact(int);
void main()
{
int n;
clrscr();
printf("\n number is n:");
scanf("%d",&n);
fact(n);
getch();
}
void fact(int n)
{
long int i,fact=1;
for(i=1;i<=n;i++)
{
fact=fact*i;
}
printf("\n value of N=%d\t fact=%ld",n,fact);
}




































