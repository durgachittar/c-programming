main()
{
clrscr();
india(); //calling function india
usa();
india();
india();
usa();
getch();
}

india()  //defining or creating function india()
{
printf("\nIndia is my country");
}
usa()
{
printf("\nAmerica");
}