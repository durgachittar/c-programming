	#include<stdio.h>
	#include<conio.h>

	void main()
	{
		int num1,num2;
		int temp;

		clrscr();
		printf("Enter two numbers :");
		scanf("%d%d",&num1,&num2);

		temp = num1;
		num1 = num2;
		num2 = temp;
		printf("Swaping values are\n");
		printf("num1 = %d \t num2 = %d\n",num1,num2);
	}

