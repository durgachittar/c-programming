#include <conio.h>
#include <stdio.h>
#include<math.h>
void main()
{
int a,b,c;
float r,q1,q2;
clrscr();
printf("Enter the number:");
scanf("%d%d%d",&a,&b,&c);
r=sqrt((b*b)-(4*a*c));
q1=(-b+r)/(2*a);
q2=(-b-r)/(2*a);
printf("q1=%f\tq2=%f",q1,q2);
}