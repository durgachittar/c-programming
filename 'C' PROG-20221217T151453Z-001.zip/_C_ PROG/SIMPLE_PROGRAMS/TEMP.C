       #include<stdio.h>
       #include<conio.h>

       void main()
       {
		float ct,ft;

		clrscr();
		printf("Enter the centigrade temprature :");
		scanf("%f",&ct);

		ft = (9.0/5.0) * ct + 32;
		printf("Fahrenheit temprature = %f",ft);

       }