#include<conio.h>
#include<stdio.h>
main()
{
int p,n,r;
float si;
clrscr();
printf("Enter the number:");
scanf("%d%d%d",&p,&n,&r);
si=p*n*r/100;
printf("si=%f",si);
getch();
}