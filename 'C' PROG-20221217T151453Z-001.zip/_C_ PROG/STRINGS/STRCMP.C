
	#include<stdio.h>
	#include<conio.h>
	#include<string.h>

	void main()
	{
		char str1[20],str2[20];
		int i;

		clrscr();
		printf("Enter first string :");
		gets(str1);
		printf("Enter second string :");
		gets(str2);

		/*
			strcmp(string1,string2);
			The string comparison starts with the first
			character in each string and continues with
			subsequent characters until the corresponding
			characters differ or until the end of the
			strings is reached.

			These routines return an int value that is
			  value >  0  if s1 >  s2
			  value == 0  if s1 == s2
			  value <  0  if s1 <  s2


		*/

		i = strcmp(str1,str2);
		printf("i = %d\n",i);
		if(i > 0)
		{
			printf("String1 is greater");
		}
		else if(i < 0)
		{
			printf("String2 is greater");
		}
		else
		{
			printf("Both strings are same");
		}
	     getch();

	}


