	#include<stdio.h>
	#include<conio.h>


	void main()
	{
		char str[20];
		int i;

		clrscr();
		printf("Enter a string :");
		gets(str);

		i = 0;
		while(str[i] != '\0')
		{
			printf("\t%c\n",str[i]);
			i++;
		}

	}