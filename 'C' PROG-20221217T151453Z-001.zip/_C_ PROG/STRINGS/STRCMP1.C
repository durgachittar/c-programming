138.	LIBRARY STRING FUNCTION STRCMP().
		main()
		{
			char string1[] = �JERRY�;
			char string2[] = �FERRY�;
			int i, j, k;
			i = strcmp (string1, �JERRY�);
			j = strcmp (string1, string2);
			k = strcmp (string1, �JERRY BOY�);
			printf ("\n %d %d %d�,i, j, k);
	}
