	#include<stdio.h>
	#include<conio.h>

	/*
		String - Group of characters(Char array)

		declaration
		char <string name>[size];
		[] - subscript

		e.g
			char str[20];
			str = sai
			str[0] = s
			str[1] = a
			str[2] = i
			str[3] = \0 i.e. null character
			Each string ends with null character.

	*/

	void main()
	{
		char str[20];

		clrscr();
		printf("Enter a string :");
	       //	scanf("%s",str);
		gets(str); //read a string with space and tab

		printf("String = %s",str);
		getch();
	}