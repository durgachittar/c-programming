#include<stdio.h>
#include<conio.h>
main()
{
char name[]="sai computer";      `
int i=0;
clrscr();
while (name[i]!='\0')
{
printf("%c",name[i]);
i++;
}
}
