	#include<stdio.h>
	#include<conio.h>
	#include<string.h>


	int stringlen(char *s)
	{
		int cnt=0;
		while(*s != '\0')
		{
			cnt++;
			s++;
		}
		return(cnt);
	}

	int palindrome(char *s)
	{
		int flag = 0,l;
		char *temp;
		l = stringlen(s)-1; //5


		//l = 5
		//l-1 = 4
		temp = s;
		while(*s != '\0')
		{
			if(*s != *(temp+l))
			{
				flag = 1;
				break;
			}
			l--;
			s++;
		}
		return(flag);

	}

	void main()
	{
		char str[20];
		int l,flag=0;

		clrscr();
		printf("Enter a string :");
		gets(str);
		//0 1 2 3 4
		//m a d a m
		flag = palindrome(str);
		if(flag == 0)
		{
			printf("String is plaindrome");
		}
		else
		{
			printf("String is not plaindrome");
		}

	}
