#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
      char str1[20],str2[20];
      int i;
      clrscr();
      printf("enter first string:");
      gets(str1);
      printf("enter second string:");
      gets(str2);
      i=strcmp(str1,str2);
      printf("i=%d\n",i);
      if(i>0)
      {
	   printf("String1 is greater");
      }
      else if(i<0)
      {
	   printf ("string 2 is greater");
      }
      else
      {
	  printf("both string are same");
      }
}