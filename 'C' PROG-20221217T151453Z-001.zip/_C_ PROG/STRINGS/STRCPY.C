	#include<stdio.h>
	#include<conio.h>
	#include<string.h>

	void main()
	{
		char str1[20],str2[20];

		clrscr();
		printf("Enter a string :");
		gets(str1);

		/*
			strcpy(destination string,source string);
			Copies source string  to destination string
		*/
		strcpy(str2,str1);
		printf("Copy string = %s",str2);
	}

