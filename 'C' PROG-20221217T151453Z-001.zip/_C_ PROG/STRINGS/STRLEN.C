	#include<stdio.h>
	#include<conio.h>
	#include<string.h>

	void main()
	{
		char str[20];
		int l;

		clrscr();
		printf("enter a string:");
		gets(str);

		/*
		      strlen(string)

		      Calculates length of a string.

		      Returns the number of characters in string, not
		      counting the terminating null character.

		*/

		l = strlen(str);
		printf("lenth of string=%d",l);
	}