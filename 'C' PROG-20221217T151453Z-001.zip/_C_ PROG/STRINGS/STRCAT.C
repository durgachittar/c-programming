	#include<stdio.h>
	#include<conio.h>
	#include<string.h>

	void main()
	{
		char str1[20],str2[20];

		clrscr();
		printf("Enter first string :");
		gets(str1);
		printf("Enter second string :");
		gets(str2);

		/*
			strcat(destination string,source string);
			Appends source string to destination string.

			str1 = sai
			str2 = computer
		      c	str = sai computer

		*/

		strcat(str1," ");
		strcat(str1,str2);
		printf("Concat string = %s",str1);
		 getch();

	}
