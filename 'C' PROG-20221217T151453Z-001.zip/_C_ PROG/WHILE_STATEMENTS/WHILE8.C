#include<stdio.h>
#include<conio.h>
#include<math.h>
void main()
{
int x,sum=0,i;
clrscr();
printf("Enter value of x:");
scanf("%d",&x);
i=1;
while(i<=4)
{
sum=sum+pow(x,i);
i++;
}
printf("%d",sum);
getch();
}

