#include<stdio.h>
#include<conio.h>
  void main()
  {
 int num=1,sum=0;
 clrscr();
 while(num<=20)
 {
 printf("%d\n",num);
 sum=sum+num;
 num=num+2;
 }
 printf("sum of first 10 odd number=%d",sum);
 getch();
 }
