 #include<stdio.h>
 #include<conio.h>
  void main()
  {
  int num=1,sum=0;     //Initilization
  clrscr();
  while(num<=10)          //condition
  {
  printf("%d\n",num);
  sum=sum+num;
  num++;
  }
  printf("sum of first 10 natural number%d",sum);
  getch();
  }