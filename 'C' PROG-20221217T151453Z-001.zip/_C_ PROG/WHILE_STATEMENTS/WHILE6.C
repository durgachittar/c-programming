#include<conio.h>
#include<stdio.h>
main()
{
int num,r,rev=0;
clrscr();
printf("Enter the number:");
scanf("%d",&num);
while(num>0)
{
r=num%10;
rev=(rev*10)+r;
num=num/10;
printf("rev number=%d",rev);
}
getch();
}