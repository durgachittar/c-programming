#include<stdio.h>
#include<conio.h>
  void main()
  {
 int num=2,sum=0;
 clrscr();
 while(num<=20)
 {
 printf("%d\n",num);
 sum=sum+num;
 num=num+2;
 }
 printf("sum of first 10 even number=%d",sum);
 getch();
 }
