 #include<stdio.h>
 #include<conio.h>
  void main()
  {
  int num=10;     //Initilization
  clrscr();
  while(num>=1)          //condition
  {
  printf("%d\n",num);
  num--;
  }
  getch();
  }