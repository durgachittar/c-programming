 #include<stdio.h>
 #include<conio.h>
  void main()
  /*
  1.while loop
	syntax
	initilization
	condition
	{
		statement
		increment/decrement
	}
  2.do while loop
	syntax
	initilization
	do
	{
		statement
		increment/decrement
	}while(condition)
  3.for loop
	syntax
	for(initilization;condition;increment/decrement)
	{
		statement
	}

  */
  {
  int num=1;     //Initilization
  clrscr();
  while(num<=10)          //condition
  {
  printf("%d\n",num);
  num++;
  }
  getch();
  }