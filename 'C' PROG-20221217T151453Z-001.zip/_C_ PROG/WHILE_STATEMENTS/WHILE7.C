#include<conio.h>
#include<stdio.h>
void main()
{
int num,fd,ld,sum;
clrscr();
printf("Enter the number:");
scanf("%d",&num);
ld=num%10;
while(num>0)
{
fd=num%10;
num=num/10;
}
sum=fd+ld;
printf("sum of fd+ld=%d",sum);
getch();

}