#include<stdio.h>
#include<conio.h>
void main()
{
int mark1, mark2, mark3;
int total,gtotal=0,i;
float avg,gavg;
clrscr();
for(i=1; i<=5; i++)
{printf("enter three marks of students:");
scanf(%d%d%d",&mark1,&mark2,&mark3);
total=mark1+mark2+mark3;
avg = gtotal/3.0;
gtotal=gtotal+total;
printf("roll no=%d\t total
