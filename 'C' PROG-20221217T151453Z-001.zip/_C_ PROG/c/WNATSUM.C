	#include<stdio.h>
	#include<conio.h>


	void main()
	{
		int num,sum=0;

		clrscr();
		num = 1;
		while (num <= 10)
		{
			sum = sum + num;
			num++; //inc
		}
		printf("sum of 10 natural numbers = %d",sum);
	}