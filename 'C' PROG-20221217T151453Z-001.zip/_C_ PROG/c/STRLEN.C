#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
	char str[20];
	int l;
	clrscr();
	printf("enter a string:");
	gets(str);
	l=strlen(str);
	printf("lenth of string=%d",l);
}