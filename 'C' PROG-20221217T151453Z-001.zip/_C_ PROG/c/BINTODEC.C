	#include<stdio.h>
	#include<conio.h>
	#include<math.h>


	void main()
	{
		int num;
		int dec=0,i,r;

		clrscr();
		printf("Enter the binary number :");
		scanf("%d",&num);
		//for(i=0; num>0; i++)
		i = 0;
		while(num > 0)
		{
			r = num % 10;
			dec = dec + (r*pow(2,i));
			i++;
			num = num / 10;
		}

		printf("Decimal number = %d",dec);
	}