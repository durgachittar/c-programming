#include<stdio.h>
#include<conio.h>
void main()
{
     int i,ans;
     clrscr();
     for(i=1;i<=10;i++)
      {
	   ans=i*3;
	   printf("%2d*3=%2d\n",i,ans);
       }
}