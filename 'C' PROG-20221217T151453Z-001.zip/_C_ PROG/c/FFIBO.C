	#include<stdio.h>
	#include<conio.h>


	void main()
	{
		int num,a,b,c;
		int i;

		clrscr();
		printf("Enter the number of terms :");
		scanf("%d",&num);

		a = 0;
		b = 1;
		c = 0;
		for(i=1; i<=num; i++)
		{
			printf("%d\t",c);
			a = b;
			b = c;
			c = a + b;
		}
	}