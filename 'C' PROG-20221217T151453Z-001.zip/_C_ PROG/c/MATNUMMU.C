	#include<stdio.h>
	#include<conio.h>

	/*
		 0 1 2

	      0  1 2 3        2  4  6
	      1  4 5 6  * 2 = 8 10 12
	      2  7 8 9       14 16 18

	 */

	void main()
	{
		int m[3][3],i,j,num;

		clrscr();
		for(i=0; i<3; i++)//row
		{
			for(j=0; j<3; j++)//col
			{
				printf("Enter the value of m[%d][%d] ",i,j);
				scanf("%d",&m[i][j]);
			}
		}

		printf("Matrix\n");
		for(i=0; i<3; i++)
		{
			for(j=0; j<3; j++)
			{
				printf("%2d ",m[i][j]);
			}
			printf("\n");
		}

		printf("Enter the number :");
		scanf("%d",&num);
		printf("Matrix number multiplication\n");
		for(i=0; i<3; i++)
		{
			for(j=0; j<3; j++)
			{
				m[i][j] = num * m[i][j];
				printf("%2d ",m[i][j]);
			}
			printf("\n");
		}

	}