	#include<stdio.h>
	#include<conio.h>

	/*
		num = 123
		rev = 321

		123 % 10 = 3
		123 / 10 = 12
	*/
	void main()
	{
		int num;
		int r,rev=0;

		clrscr();
		printf("Enter the number :");
		scanf("%d",&num);

		while(num > 0)
		{
			r = num%10;
			rev = (rev*10) + r;
			num = num / 10;
		}
		printf("Reverse number = %d",rev);
	}