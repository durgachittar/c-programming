	#include<stdio.h>
	#include<conio.h>


	void main()
	{
		int num,s,c,r,sum;
		int temp;

		clrscr();
		for(num=1; num<=1000; num++)
		{
			temp = num;
			sum = 0;
			while(temp > 0)
			{
				r = temp % 10;
				c = r * r * r;
				sum = sum + c;
				temp = temp / 10;
			}
			if(num == sum)
			{
				printf("\t%d\n",num);
			}
		}
	}