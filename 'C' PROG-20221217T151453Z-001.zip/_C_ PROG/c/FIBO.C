	#include<stdio.h>
	#include<conio.h>

	/*
		fIBONACCI series
		Next number will be the addition of previous two numbers.
		0 1 1 2 3 5 8 13__________
	*/

	void main()
	{
		int num,a,b,c;

		clrscr();
		printf("Enter the limit :");
		scanf("%d",&num);
		a = 0;
		b = 1;
		c = 0;
		while(c <= num)
		{
			printf("%d\t",c);
			a = b;
			b = c;
			c = a + b;
		}
	}