		#include<stdio.h>
		#include<conio.h>

		/*
			10 + 0  = 10
			9  + 1  = 10
			8  + 2  = 10
			7  + 3  = 10
			|
			|
			|
			|
			0  + 10  = 10
		*/

		void main()
		{
			int i,j,sum;

			clrscr();
			for(i=10,j=0; i>=0,j<=10; i--,j++)
			{
				sum = i + j;
				printf("%2d + %2d = %2d\n",i,j,sum);
			}
		}