	#include<conio.h>
	#include<stdio.h>

	void main()
	{
	 float ct,ft;
	 clrscr();
	 printf("Enter the centigrade temp");
	 scanf("%f",&ct);
	 ft=(9.0/5.0)*ct+32;
	 printf("Fahrenheite temp =%1.2f",ft);
	 }