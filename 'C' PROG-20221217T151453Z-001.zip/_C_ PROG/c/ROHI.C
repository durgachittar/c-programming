#include<stdio.h>
#include<conio.h>
void main()
{
int marks;
clrscr();
printf("enter the two marks:");
scanf("%d%d",&marks);
if(marks>=35)
{
printf("pass");
}
else
{
printf("fail");
}
}
