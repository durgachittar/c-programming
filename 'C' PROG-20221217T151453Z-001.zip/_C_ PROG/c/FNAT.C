	#include<stdio.h>
	#include<conio.h>

	void main()
	{
		int num;

		clrscr();
		for(num=1; num<=10; num++)
		{
			printf("\t\t%d\n",num);
		}
	}