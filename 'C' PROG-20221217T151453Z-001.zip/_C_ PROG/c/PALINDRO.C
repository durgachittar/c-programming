	#include<stdio.h>
	#include<conio.h>
	#include<string.h>

	/*
		Palindrome
		madam
		nitin
		malayalam
		pop
	*/
	int stringlen(char s[])
	{
		int i=0,cnt=0;
		while(s[i] != '\0')
		{
			i++;
			cnt++;
		}
		return(cnt);
	}

	void main()
	{
		char str[20];
		int i,l,flag=0;

		clrscr();
		printf("Enter a string :");
		gets(str);
		l = stringlen(str); //5

		//madam

		i = 0;
		while(str[i] != '\0')
		{
			if(str[i] != str[l-1])
			{
				flag = 1;
				break;
			}
			i++;
			l--;
		}

		if(flag == 0)
		{
			printf("String is palindrome");
		}
		else
		{
			printf("String is not palindrome");
		}
	}
