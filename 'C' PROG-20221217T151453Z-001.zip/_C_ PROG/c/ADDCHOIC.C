	#include<stdio.h>
	#include<conio.h>

	void main()
	{
		int num1,num2,ans;
		char ch;

		clrscr();
		printf("Enter two numbers :");
		scanf("%d%d",&num1,&num2);

		printf("A. Addition\n");
		printf("Enter the choice :");
		flushall(); //clear input memory
		//fflush(stdin);
		scanf("%c",&ch);

		/*
			5 7 enter
			ASCII
			American Standard Code for Information Interchange
			A-Z = 65-90
			a-z = 97-122
			0-9 = 48-57
		*/

		if(ch==  'a' || ch=='A')
		{
			ans = num1 + num2;
			printf("Answer = %d",ans);
		}
		else
		{
			printf("You have entered wrong choice");
		}

	}
