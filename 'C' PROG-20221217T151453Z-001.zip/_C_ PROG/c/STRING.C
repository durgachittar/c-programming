#include<stdio.h>
#include<conio.h>
void main()
{
    char str[20];
    clrscr();
    printf("enter a string:");
    gets(str);
    printf("string =%s",str);
}