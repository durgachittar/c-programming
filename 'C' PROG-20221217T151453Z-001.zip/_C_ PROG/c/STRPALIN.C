	#include<stdio.h>
	#include<conio.h>
	#include<string.h>

	/*
		malayalam
		pop
		madam
	*/

	int stringlen(char s[])
	{
		int i=0;
		int cnt=0;
		while(s[i] != '\0')
		{
			cnt++;
			i++;
		}
		return(cnt);
	}
	void main()
	{
		char str[20];
		int l,i,flag=0;

		clrscr();
		printf("Enter a string :");
		gets(str);
		//0 1 2 3 4
		//m a d a m
		l = stringlen(str); //5
		i=0;
		//l = 5
		//l-1 = 4
		while(str[i] != '\0')
		{
			if(str[i] != str[l-1])
			{
				flag = 1;
				break;
			}
			i++;//
			l--;
		}
		if(flag == 0)
		{
			printf("String is plaindrome");
		}
		else
		{
			printf("String is not plaindrome");
		}

	}