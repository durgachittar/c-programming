#include<stdio.h>
#include<conio.h>

//main function definition

void main()
{
	char ch,ans;
	FILE *fs=NULL,*ft=NULL;
	clrscr();
	fs = fopen("c:\\src.txt","w+");   //open source file in write mode\
	ft = fopen("c:\\tgt.txt","w+");
	if(fs==NULL && ft==NULL)
	    printf("\n\nUnable to open the file");
	else
	{
	printf("\nEnter the text for the source file:\n\n");
	printf("Type ~ to stop writing \n");
		do
		{

			scanf("%c",&ch);
			if(ch != '~')
				putc(ch,fs);
		}while(ch != '~');
	}
	fseek(fs,0,SEEK_SET);

	printf("Contents of source file\n");
	if(fs==NULL && ft==NULL)
		printf("\n\nCannot open the file");
	else
	{
		while((ch=getc(fs))!=EOF)
		{
			printf("%c",ch);
			if(ch>=65 && ch<=90)
				ch+=32;    //toggle lower case to upper case
			else if(ch>=97 && ch<=122)
				ch-=32;   //toggle upper case to lower case
			putc(ch,ft);
		}
	}

	printf("Contents of target file\n");
	fseek(ft,0,SEEK_SET);
	do
	{
		ch = getc(ft);
		printf("%c",ch);
	}while(ch != EOF);

	fclose(ft);   //close source file
	fclose(fs);   //close target file

	getch();
}
