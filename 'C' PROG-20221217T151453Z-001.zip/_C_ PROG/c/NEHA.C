#include<stdio.h>
#include<conio.h>
void main()
{
 int n,i,sum=0;
 clrscr();
 printf("Enter value of n:");
 scanf("%d",&n);
 for(i=1;i<=n;i++)
 sum=sum+n;
 printf("Sum of integer =%d",sum);


}