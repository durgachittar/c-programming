	#include<stdio.h>
	#include<conio.h>


	void main()
	{
		int num,s,c,r,sum;
		int temp;

		clrscr();
		printf("Enter the number :");
		scanf("%d",&num);
			temp = num;
			sum = 0;
			while(temp > 0)
			{
				r = temp % 10;
				c = r * r * r;
				sum = sum + c;
				temp = temp / 10;
			}
			if(num == sum)
			{
				printf("Number is armstrong");
			}
			else
			{
				printf("Number is not armstrong");
			}

	}