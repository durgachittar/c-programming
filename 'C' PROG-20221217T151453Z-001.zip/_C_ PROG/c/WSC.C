	#include<stdio.h>
	#include<conio.h>

	void main()
	{
		int num;
		int s,c;

		clrscr();
		printf("Number Square Cube\n");
		num = 1;
		while(num <= 10)
		{
			s = num*num;
			c = num*num*num;
			printf("%d\t%d\t%d\n",num,s,c);
			num++;
		}
	}