		#include<stdio.h>
		#include<conio.h>

		void main()
		{
			int num,i,flag=0;

			clrscr();
			printf("Enter the number :");
			scanf("%d",&num);

			for(i=2; i<=num-1; i++)
			{
				if(num%i == 0)
				{
					flag = 1; //no prime
					break;
				}
			}

			if(flag == 0)
			{
				prime("Number is prime");
			}
			else
			{
				printf("Number is not prime");
			}
		}