	#include<stdio.h>
	#include<conio.h>

	/*
		Automatic storage class
		declaration
		auto <data type> <variable name>
		Defines a local variable as having a local lifetime.

		By default all variables declarared in automatic storage class.

		By default stores garbage value.
	*/

	void main()
	{
		auto int i =10;

		clrscr();
		printf("value of i = %d\n",i);//10
		{
			int j;
			auto int i=20;
			printf("value of i = %d\n",i);//20
			{
				auto int i=30;
				printf("value of i = %d\n",i);//30
			}
			printf("value of i = %d\n",i); //20
		}
		printf("value of i = %d\n",i); //10
	}

