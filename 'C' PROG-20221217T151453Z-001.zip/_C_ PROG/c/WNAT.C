	#include<stdio.h>
	#include<conio.h>

	/*
		Loop
		1. while loop
			syntax
			init
			while (condition)
			{
				statements
				inc / dec
			}
		2. do while loop
			syntax
			init
			do
			{
				statments
				inc / dec
			}while(condition);
		3. for loop
			syntax
			for(init; condition; inc / dec)
			{
				statemnets
			}
	*/

	void main()
	{
		int num;

		clrscr();
		num = 1; //init
		while (num <= 10)
		{
			printf("\t %d \n",num);
			num++; //inc
			//num = num + 1;
		}
	}