	#include<stdio.h>
	#include<conio.h>

	/*
		 0 1 2

	      0  1 2 3
	      1  4 5 6
	      2  7 8 9

	      matrix - (2D array)
	      syntax
	      <data type> <matrix name>[row][col];
	*/

	void main()
	{
		int m[3][3],i,j;

		clrscr();
		for(i=0; i<3; i++)//row
		{
			for(j=0; j<3; j++)//col
			{
				printf("Enter the value of m[%d][%d] ",i,j);
				scanf("%d",&m[i][j]);
			}
		}

		printf("Matrix\n");
		for(i=0; i<3; i++)
		{
			for(j=0; j<3; j++)
			{
				printf("%2d ",m[i][j]);
			}
			printf("\n");
		}

	}