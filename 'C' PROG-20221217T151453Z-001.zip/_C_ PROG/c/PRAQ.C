#include<stdio.h>
#include<conio.h>

void main()
{
int num;
int a,b,c;
clrscr();
printf("Enter the limit:");
scanf("%d",&num);
a=0;
b=1;
c=0;
while(c<=num)
{
printf("%d\t",c);
a=b;
b=c;
c=a+b;
}
}
