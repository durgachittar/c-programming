	#include<stdio.h>
	#include<conio.h>


	void main()
	{
		int num,sum=0;

		clrscr();
		num = 1;
		while (num <= 20)
		{
			printf("\t%d\n",num);
			sum = sum + num;
			num = num + 2; //inc
		}
		printf("sum of 10 odd numbers = %d",sum);
	}