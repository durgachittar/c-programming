	#include<stdio.h>
	#include<conio.h>
	#include<math.h>


	void main()
	{
		int x,i,sum=0;

		clrscr();
		printf("Enter the value of x :");
		scanf("%d",&x);
		i = 1;
		while (i <= 4)
		{
			sum = sum + pow(x,i); //pow(base,expo)
			i++;
		}
		printf("sum of x = %d",sum);
	}