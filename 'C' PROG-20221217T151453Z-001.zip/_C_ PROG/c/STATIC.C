	#include<stdio.h>
	#include<conio.h>

	/*
		static storage class
		declaration
		static <data type> <variable name>

		preserves variable value.

			If you use the "static" keyword with a
			variable that is local to a function, it
			allows the last value of the variable to be
			preserved between successive calls to that
			function.

		By default stores zero value.
	*/

	void fun()
	{
		static int num1=10;
		static int num2=20;
		printf("%d \t %d \t",num1,num2);
		num1++;
		num2++;
		printf("%d \t %d \n",num1,num2);
	}

	void main()
	{
		clrscr();
		fun();
		fun();
		fun();
	}


