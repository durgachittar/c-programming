		   #include<stdio.h>
		   #include<conio.h>


		   void stringrev(char *s)
		   {
			char *stemp;
			for(;*s!='\0';s++);

			stemp = s;
			for(s--; *s>=0 ;s--,stemp++)
			{
				*stemp = *s;
			}

			*stemp = '\0';

			//for(;*stemp>=0; stemp++);


			/*for(s++,stemp++; *stemp>=0;s++,stemp--)
			{
				*s = *stemp;
			}*/
		   }


		   void main()
		   {
		   char str[20];
		   clrscr();
			printf("\nEnter a string:");
			gets(str);
			stringrev(str);
			printf("string reverse is %s",str);
		   }



