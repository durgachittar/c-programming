#include<stdio.h>
#include<conio.h>

void main()
{
     int i,j;
     int ans;
     clrscr();

     for(i=1;i<=10;i++)
     {
      for(j=1;j<=10;j++)
      {



      ans=i*j;


      printf("%2d * %2d =%2d\n",i,j,ans);
      }
      getch();

      }
      }