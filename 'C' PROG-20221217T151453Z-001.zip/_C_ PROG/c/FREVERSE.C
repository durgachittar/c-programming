#include<tdio.h>
#include<conio.h>
void main()
{
int num;
clrscr();
for (num=10;num>=1;num--)
{
printf("\t%d\n",num);
}
}