	#include<stdio.h>
	#include<conio.h>

	void main()
	{

		int num;
		int sum=0;

		clrscr();
		num = 1;
		while(num <= 20)
		{
			sum = sum + num;
			num = num + 2;
		}

		printf("Sum of first 10 odd numbers = %d",sum);
	}

