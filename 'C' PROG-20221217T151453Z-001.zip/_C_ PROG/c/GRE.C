#include<stdio.h>
#include<conio.h>

void main()
{
int n1,n2,n3;
clrscr();
printf("Enter the three numbers::");
scanf("%d%d%d",&n1,&n2,&n3);
if(n1>n2 && n1>n3)
{
 printf("Number1 is greater");
 }
else if(n2>n1 && n2>n3)
{
 printf("Number2 is greater");
}
else if(n3>n1 && n3>n1)
{
printf("Number3 is greater");
}

else
{
printf("All numbers are same");
}
}