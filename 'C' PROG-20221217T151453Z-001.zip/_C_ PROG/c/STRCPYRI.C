#include<stdio.h>
#include<conio.h>
#include<string.h>
  void main()
  {
       char str1[20],str2[20];
       clrscr();
       printf("enter first string:");
       gets(str1);
       printf("enter second string:");
       gets(str2);
       strcat(str1," ");
       strcat(str1,str2);
       printf("concat string=%s",str1);
  }
