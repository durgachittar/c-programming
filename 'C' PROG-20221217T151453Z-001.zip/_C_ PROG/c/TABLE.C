		#include<stdio.h>
		#include<conio.h>

		/*
			1 * 2  = 2
			2 * 2  = 4
			3 * 2  = 6
			4 * 2 = 8
			|
			|
			|
			|10 * 2 = 20
		*/

		void main()
		{
			int i,ans;

			clrscr();
			for(i=1; i<=10; i++)
			{
				ans = i * 2;
				printf("%2d * 2 = %2d\n",i,ans);
			}
		}