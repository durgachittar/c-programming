	#include<conio.h>
	#include<stdio.h>
	#include<math.h>

	void main()
	{
		int a,b,c;
		float r1,r2,r;

		clrscr();
		printf("Enter the values of a,b,c :");
		scanf("%d%d%d",&a,&b,&c);

		r = sqrt((b*b) - (4*a*c));

		r1 = (-b+r) / (2*a);
		r2 = (-b-r) / (2*a);

		printf("Root1 = %f \t Root2 = %f",r1,r2);

	}