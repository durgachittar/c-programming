	 #include<stdio.h>
	 #include<conio.h>

	 void main()
	 {
		int num;

		clrscr();
		printf("Enter the number :");
		scanf("%d",&num);

		if(num%7 == 0)
		{
			printf("Number is divisible by 7");
		}
		else
		{
			printf("Number is not divisible by 7");
		}
	 }