	#include<stdio.h>
	#include<conio.h>


	//addition of two numbers
	void main()
	{

	}





