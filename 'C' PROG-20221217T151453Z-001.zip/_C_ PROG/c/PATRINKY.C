#include<stdio.h>
#include<conio.h>
void maain()
{
      int i,j;
      clrscr();
      for(i