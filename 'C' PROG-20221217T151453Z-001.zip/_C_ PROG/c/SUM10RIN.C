#include<stdio.h>
#include<conio.h>
void main()
{
	   int i,j,sum;
	   clrscr();
	   for(i=10,j=0;i>=0,j<=10;i--,j++)
	   {
	   sum=i+j;
	   printf("%2d+%2d=%2d\n",i,j,sum);
	   }
 }
