#include<stdio.h>
#include<conio.h>

void main()
{
     int num1,num2;

     int ans;

     clrscr();
     printf("Enter first number:");
     scanf("%d",&num1);
     printf("Enter second number:");
     scanf("%d",&num2);
     ans=num1-num2;
     printf("Answer=%d",ans);
}