	 #include<stdio.h>
	 #include<conio.h>

	 void main()
	 {
		int x,y;

		clrscr();


		printf("Enter the value of x :");
		scanf("%d",&x);
		/*
			?: - conditional operator
			syntax
			condition ? true value : false value
		*/
		/*if(x > 5)
		{
			y = 3;
		}
		else
		{
			y = 4;
		}*/
		y = (x > 5 ? 3:4);
		printf("x = %d \t y = %d",x,y);
	 }
