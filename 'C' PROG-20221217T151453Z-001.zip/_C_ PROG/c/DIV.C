       #include<stdio.h>
       #include<conio.h>

       void main()
       {
		int num1,num2;
		float ans;

		clrscr();
		printf("Enter two numbers :");
		scanf("%d%d",&num1,&num2);

		ans = num1 / num2;
		printf("answer = %f",ans);

       }