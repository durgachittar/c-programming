	#include<stdio.h>
	#include<conio.h>

	/*
		register storage class
		declaration
		register <data type> <variable name>
		store the variable being declared in a CPU register
		By default stores garbage value.
	*/
