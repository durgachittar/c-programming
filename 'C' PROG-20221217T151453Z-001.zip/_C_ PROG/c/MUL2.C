#include<stdio.h>
#include<conio.h>

void main()
{
 int i,ans;
 clrscr();
 for(i=1;i<=10;i++)
 {
 ans=i *4;
 printf("%2d * 4 =%2d\n",i,ans);
 }
}
