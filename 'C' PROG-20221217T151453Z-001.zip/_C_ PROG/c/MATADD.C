#include<stdio.h>
#include<conio.h>
void main()
{
	int m1[3][3],m2[3][3],i,j,sum[3][3];
	clrscr();
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			printf("enter elements in m[%d][%d]",i,j);
			scanf("%d",&m1[i][j]);
		}
	}
	printf("Enter the second matrix\n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			printf("enter elements in t[%d][%d]",i,j);
			scanf("%d",&m2[i][j]);
			sum[i][j] = m1[i][j] + m2[i][j];
		}
	}
	printf("matrix1\n");
		for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			printf("%d",m1[i][j]);
		}
		printf("\n");
	}
	printf("matrix2\n");
		for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			printf("%d",m2[i][j]);
		}
		printf("\n");
	}

	printf("Sum of matrices\n");
		for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
		   printf("%2d ",sum[i][j]);
		}
		printf("\n");
	}
}