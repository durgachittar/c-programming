	#include<stdio.h>
	#include<conio.h>

	void main()
	{
		char ch;

	       clrscr();
		printf("enter a character:");
		scanf("%c",&ch);

		printf("ch = %c\t ascii = %d\n",ch,ch);

		//if((ch>='A' && ch<='Z') || (ch>='a' && ch<='z'))
		if((ch>=65 && ch<=90) || (ch>=97 && ch<=122))
		{
			printf("It is an alphabet");
		}
		//else if(ch>='0' && ch<='9');
		else if(ch>=48 && ch<=57)
		{
			printf("It is a digit");
		}
		else
		{
			printf("It is a special character");
		}
	       }

