	#include<stdio.h>
	#include<conio.h>


	void main()
	{
		int num;

		clrscr();
		num = 10;
		while (num >= 1)
		{
			printf("\t%d\n",num);
			num--; //dec num = num - 1
		}
	}