	#include<stdio.h>
	#include<conio.h>

	void main()
	{

		int num;
		int sum=0;

		clrscr();
		num = 2;
		while(num <= 20)
		{
			sum = sum + num;
			num = num + 2;
		}

		printf("Sum of first 10 even numbers = %d",sum);
	}




