	#include<stdio.h>
	#include<conio.h>
	#include<math.h>


	void main()
	{
		int num;
		int bin=0,i,r;

		clrscr();
		printf("Enter the decimal number :");
		scanf("%d",&num);
		//for(i=0; num>0; i++)
		//num = 12
		i = 0;
		while(num > 0)
		{
			r = num % 2;//1
			bin = bin+ (r*pow(10,i));//1100
			i++;//4
			num = num / 2;//0
		}

		printf("Binary  number = %d",bin);
	}