	#include<stdio.h>
	#include<conio.h>

	void main()
	{
		float p,n,r;
		float si;
		int i;

		clrscr();
		i = 1;
		while(i <= 3)
		{
			printf("\nEnter values of p,n,r :");
			scanf("%f%f%f",&p,&n,&r);

			si = p*n*r / 100;
			printf("Simple interest = %f",si);
			i++;
		}
	}