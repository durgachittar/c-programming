#include<stdio.h>
#include<conio.h>
void main()
{
char str1[20];
int i,j,cnt,flag=0;
clrscr();
printf("Enter a string:");
gets(str1);
i=0;
	printf("\nForward string:");
	while(str1[i]!='\0')
	{
	printf("%c",str1[i]);
	i++;
	}
	cnt=i;
	printf("\nBackward string:");
	while(i>=0)
	{
	printf("%c",str1[i]);
	i--;
	}
	for (i=0,j=cnt-1;i!='\0',j>=0;i++,j--)
	{
		if (str1[i] != str1[j])
		{
		flag=1;
		break;
		}
	}
	if (flag==0)
	printf("\nPalindrome");
	else
	printf("\nNot a palindrome");
}