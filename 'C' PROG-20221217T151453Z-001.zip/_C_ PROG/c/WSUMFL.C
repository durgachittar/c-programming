	#include<stdio.h>
	#include<conio.h>


	/*
		num = 123
		1+3 = 4
	*/
	void main()
	{
		int num;
		int fd,ld,sum;

		clrscr();
		printf("Enter the number :");
		scanf("%d",&num);

		ld = num%10;
		while(num > 0)
		{
			fd = num;
			num = num / 10;
		}
		sum = fd + ld;
		printf("sum of first digit and last digit = %d",sum);
	}