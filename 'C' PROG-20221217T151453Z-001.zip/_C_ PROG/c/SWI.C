#include<stdio.h>
#include<conio.h>
void main()
{
int a,b,c;
float e, ave;
int ch;
clrscr();
printf("Enter the values of a,b:");
scanf("%d%d",&a,&b);

printf("Enter the choice:");
scanf("%d",&ch);

switch(ch)
{
   case 1:
   {
   c= a+b;
   printf("Addition =%d",c);
   }
   case 2:
   {
   c=a-b;
   printf("Substraction=%d",c);
   }
   case 3:
   {
   c=a*b;
   printf("Multiplication=%d",c);
   }
   case 4:
   {
   e=a/b;
   printf("Division=%f",e);}
   case 5:
   {
   ave=(a+b)/2;
   printf("Average of the two is =%f",ave);
   }

 }
}

