main()
{
int r;
float a,c;
clrscr();
printf("Enter radius: ");
scanf("%d",&r);
areacir(r,&a,&c);
printf("Area of circle is %f",a);
printf("\nCircumference of circle is %f",c);
getch();
}

areacir(int x, float *y, float *z)
{
*y=3.14*x*x;
*z=2*3.14*x;
}



