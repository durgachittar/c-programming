/*pointers and strings*/
main()
{
/*char str[]="HELLO";*/
char *str="HELLO";
clrscr();
printf("%s",str);
/*
str[2]='M';
*/
*(str+2)='M';
printf("\n%s",str);
getch();
}



