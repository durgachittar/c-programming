/*
dynammic memory allocation

syntax for malloc:

(datatype *)malloc(size of memory in bytes)

*/
#include<alloc.h>
main()
{
int n,i,*ptr,sum=0,avg;
clrscr();

printf("Enter number of students: ");
scanf("%d",&n);

ptr=(int *) malloc(n*2);
/*
ptr=(int *) calloc(n,2);
*/

printf("\n\nEnter total marks of students:\n");
for(i=0;i<n;i++)
scanf("%d",(ptr+i));

for(i=0;i<n;i++)
sum=sum+(*(ptr+i));

avg=sum/n;

printf("\n\nAverage of all students is %d",avg);
getch();
}
