/*pointers and functions*/
main()
{
int no[5],i;
clrscr();
printf("Enter 5 numbers:\n");
for(i=0;i<5;i++)
scanf("%d",&no[i]);
display(&no);
getch();
}

display(int *ptr)
{
int i;
printf("Entered 5 numbers:\n");
for(i=0;i<5;i++)
printf("%d\n",*(ptr+i));
}