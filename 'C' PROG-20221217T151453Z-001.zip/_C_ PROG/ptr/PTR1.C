/*
pointer - that points to some memory locations to access value that loc.
*(address) = value at that address

pointer symbols:
*    pointer
&    address
->   pointing at

i=10
&i    memory address of i
*(&i) value at the address of i i.e value of i i.e. 10
      i.e. * and & cancels each other

int i=10,k;   normal variable
int *j;     pointer variable used to store address of a variable

k=&i;    error
j=&i;    works

*/

main()
{
int i=10;
clrscr();
printf("Value of i is %d",i);
printf("\nAddress of i is %u",&i);
getch();
}











