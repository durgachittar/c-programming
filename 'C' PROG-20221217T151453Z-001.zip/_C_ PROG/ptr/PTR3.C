main()
{
int i=10,*j,**k;
clrscr();
j=&i;
k=&j;
printf("Value of i is %d",i);
printf("\nAddress of i is %u",&i);
printf("\nValue of i is %d",*(&i));
printf("\n\nAddress of i is %u",j);
printf("\nValue of j is %u",j);
printf("\nAddress of j is %u",&j);
printf("\nValue of i is %d",*j);

printf("\n\nValue of k is %u",k);
printf("\nAddress of k is %u",&k);
printf("\nValue of j ie. address of i is %u",*k);
printf("\nValue of i is %d",**k);
/*
*j = *(&i) = i

*k = *(&j) = j = &i

**k = **(&j) = *j = *(&i) = i

*/

getch();
}











