/*pointers and arrays*/
main()
{
int no[5],i,*ptr;
clrscr();

ptr=&no;
/*
ptr=&no[0];
*/

printf("Enter 5 numbers:\n");
for(i=0;i<5;i++)
{
scanf("%d",(ptr+i));
/*
scanf("%d",&no[i]);
*/
}

printf("Entered 5 numbers:\n");
for(i=0;i<5;i++)
{
printf("%d\n",*(ptr+i));
/*
printf("%d\n",no[i]);
*/
}

getch();
}