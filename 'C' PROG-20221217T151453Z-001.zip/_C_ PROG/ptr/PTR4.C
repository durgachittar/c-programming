/*swap by values*/
main()
{
int a=10,b=20;
clrscr();
printf("\na=%d and b=%d",a,b);
swapv(a,b);
printf("\na=%d and b=%d",a,b);
getch();
}

swapv(int x, int y)
{
int z;
z=x;
x=y;
y=z;
}