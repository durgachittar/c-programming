/*swap by reference*/
main()
{
int a=10,b=20;
clrscr();
printf("\na=%d and b=%d",a,b);
swapr(&a,&b);
printf("\na=%d and b=%d",a,b);
getch();
}

swapr(int *x, int *y)
{
int z;
z=*x;
*x=*y;
*y=z;
}