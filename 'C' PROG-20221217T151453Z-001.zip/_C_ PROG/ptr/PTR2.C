main()
{
int i=10,*j;
clrscr();
j=&i;      /*we are linking memory address of i with variable j*/
printf("Value of i is %d",i);
printf("\nAddress of i is %u",&i);
printf("\nValue of i is %d",*(&i));

printf("\n\nAddress of i is %u",j);
printf("\nValue of j is %u",j);
printf("\nAddress of j is %u",&j);
printf("\nValue of i is %d",*j);
/*

*j = *(&i) = i

*/

getch();
}











