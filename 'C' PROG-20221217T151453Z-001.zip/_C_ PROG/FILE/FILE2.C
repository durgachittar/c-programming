#include<stdio.h>
main()
{
FILE *fp;
clrscr();
fp=fopen("pr1.C","r");
if(fp==NULL)
{
puts("cannot open file");
getch();
exit(0);
}
puts("file opened");
getch();
}




