#include<stdio.h>
main()
{
FILE *fp;
char another='Y';
char name[40];
int age;
float bs;
clrscr();

fp=fopen("EMPLOYEE.DAT","w");

if(fp==NULL)
{
puts("cannot open file");
getch();
exit(0);
}

while(another=='Y')
{
printf("\n enter name,age and basic salary\n");
scanf("%s%d%f",&name,&age,&bs);
fprintf(fp,"%s %d %f\n",name,age,bs);


printf("another emplyee(y/n)");
fflush(stdin);
another=getche();
}

fclose(fp);
}
