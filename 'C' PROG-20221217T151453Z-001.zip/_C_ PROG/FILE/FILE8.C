#include<stdio.h>
main()
{
FILE *fp;
char name[40];
int age;
float bs;

clrscr();

fp=fopen("EMPLOYEE.DAT","r");
if(fp==NULL)
{
puts("cannot open file");
getch();
exit(0);
}

while(fscanf(fp,"%s %d %f",&name,&age,&bs)!=EOF)
printf("\n%s %d %f",name,age,bs);

fclose(fp);
getch();
}