#include<stdio.h>
main()
{
FILE *fp;
char ch;
int nol=0,not=0,nob=0,noc=0;
clrscr();
fp=fopen("pr1.C","r");

while(1)
{
ch=fgetc(fp);

if(ch==EOF)
break;

noc++;

if(ch==' ')
nob++;
if(ch=='\n')
nol++;
if(ch=='\t')
not++;
}
fclose(fp);
printf("\n number of characters=%d",noc);
printf("\n number of blanks=%d",nob);
printf("\n Number of tabs=%d",not);
printf("\n Number of lines=%d",nol);
getch();
}