#include<stdio.h>
main()
{
FILE *fp;
char ch;
int noc=0;
clrscr();

fp=fopen("pr1.c","rb");
if(fp==NULL)
{
puts("cannot open file");
getch();
exit(0);
}

while(1)
{
ch=getc(fp);
if(ch==EOF)
break;
noc++;
}
fclose(fp);
printf("\n Number of charcater=%d",noc);
getch();
}