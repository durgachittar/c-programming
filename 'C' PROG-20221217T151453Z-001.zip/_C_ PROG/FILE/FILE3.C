#include<stdio.h>
main()
{
FILE *fs,*ft;
char ch;
clrscr();
fs=fopen("pr1.c","r");
if(fs==NULL)
{
puts("cannot open source file");
getch();
exit(0);
}

ft=fopen("pr2.c","w");
if(ft==NULL)
{
puts("cannot open target file");
getch();
fclose(fs);
exit(0);
}

while(1)
{
ch=fgetc(fs);
if(ch==EOF)
break;
else
fputc(ch,ft);
}
fclose(fs);
fclose(ft);
printf("File copied");
getch();
}
