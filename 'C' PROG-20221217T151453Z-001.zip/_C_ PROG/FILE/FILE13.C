#include<stdio.h>
main()
{
FILE *fp;
char another='Y';
struct emp
{
char name[40];
int age;
float bs;
};
struct emp e;
clrscr();
fp=fopen("EMP.DAT","wb");

if(fp==NULL)
{
puts("cannot open file");
getch();
exit(0);
}

while(another=='Y')
{
printf("\n Enter name,age and basic salary");
scanf("%s%d%f",&e.name,&e.age,&e.bs);
fwrite(&e,sizeof(e),1,fp);
printf("add another record(y/n)");
fflush(stdin);
another=getche();
}

fclose(fp);
getch();
}
