#include<stdio.h>
main()
{
FILE *fp;
char ch;
clrscr();
fp=fopen("poem.txt","r");

if(fp==NULL)
{
printf("cannot open file");
getch();
exit(0);
}

while((ch=fgetc(fp))!=EOF)
fputc(ch,stdprn);

fclose(fp);
}