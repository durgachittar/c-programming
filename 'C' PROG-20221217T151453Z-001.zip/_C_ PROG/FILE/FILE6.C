#include<stdio.h>
main()
{
FILE *fp;
char s[80];
clrscr();
fp=fopen("sai.TXT","r");
if(fp==NULL)
{
puts("cannot open file");
getch();
exit(0);
}

while(fgets(s,79,fp)!=NULL)
printf("%s",s);

fclose(fp);
getch();
}