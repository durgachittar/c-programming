#include<stdio.h>
main()
{
FILE *fp;
char another='Y';

struct emp
{
char name[40];
int age;
float bs;
};

struct emp e;
clrscr();
fp=fopen("EMPLOYEE.DAT","w");
if(fp==NULL)
{
puts("cannot open file");
getch();
exit(0);
}

while(another=='Y')
{
printf("\n enter name,age and basic salary:");
scanf("%s%d%f",&e.name,&e.age,&e.bs);
fprintf(fp,"%s %d %f\n",e.name,e.age,e.bs);
printf("Add another record(Y/N)");
/*flushall();*/
fflush(stdin);
another=getche();
}
fclose(fp);
getch();
}