#include<stdio.h>
main()
{
FILE *fp;
char s[80];
clrscr();

fp=fopen("POEM.TXT","w");
if(fp==NULL)
{
puts("cannot open file");
getch();
exit(0);
}

printf("\n enter a few lines of Text:\n");
while(strlen(gets(s))>0)
{
fputs(s,fp);
fputs("\n",fp);
}

fclose(fp);
}