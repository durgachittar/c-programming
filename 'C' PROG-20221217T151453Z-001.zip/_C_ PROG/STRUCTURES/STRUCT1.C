#include<stdio.h>
#include<conio.h>

/*
	User defined data type
	1. Structure
	2. union

	Structure :- stores different data type value variable
	declaration
	struct <structre name>
	{

		decalertion of variables

	};
*/

struct emp
{
int eno;
int name[20];
char job[20];
float salary;
};

void main()
{
struct emp e;
/*
	  struct emp:-data type
	  e:-variable -objectcurun time entity
*/

clrscr();
printf("Enter the emp no:");
scanf("%d",&e.eno);

//We can access variable of structures using dot(.) operater

printf("Enter the emp name:");
flushall();
gets(e.name);
printf("Enter the emp job:");
gets(e.job);
printf("Enter the emp salary:");
scanf("%f",&e.salary);
printf("%d\t%s\t%s\t%f",e.eno,e.name,e.job,e.salary);
}

































