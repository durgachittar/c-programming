  #include<stdio.h>
  #include<conio.h>

 typedef char c;      //defination of char is c


/*
   we can write defination of data type using typedef
*/

typedef struct emp
{
int eno;
char name[20];
c    job[20];
int salary;
}emp;
void main()
{
int i;
emp e[3];
clrscr();
for(i=0;i<3;i++)
{
printf("Enter the emp number:");
scanf("%d",&e[i].eno);
printf("Enter the emp name:");
flushall();
gets(e[i].name);
printf("Enter the job:");
gets(e[i].job);
printf("Enter the emp salary");
scanf("%d",&e[i].salary);
}
for(i=0;i<3;i++)
{
printf("%d\t%s\t%s\t%d\n",e[i].eno,e[i].name,e[i].job,e[i].salary);
}
}