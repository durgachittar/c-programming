	#include<stdio.h>
	#include<conio.h>

	/*
		choice - int / char
		switch(choice)
		{
			case <constant value>:
				statements
				break;
			case <constant value>:
				statements
				break;
			case <constant value>:
				statements
				break;

			|
			|
			|
		}
	*/
	void main()
	{
		int num1,num2,ans;
		int ch;

		clrscr();
		printf("Enter two numbers ");
		scanf("%d%d",&num1,&num2);
		printf("1. Addition\n");
		printf("2. Subtraction\n");
		printf("3. Multiplication\n");
		printf("4. Division\n");
		printf("Enter the choice :");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				ans = num1 + num2;
				printf("Addition = %d",ans);
				break;
			case 2:
				ans = num1 - num2;
				printf("Subtraction = %d",ans);
				break;
			case 3:
				ans = num1 * num2;
				printf("Multiplication = %d",ans);
				break;
			case 4:
				ans = num1 / num2;
				printf("Division = %d",ans);
				break;
			default:
				printf("You have entered wrong choice");

		}
	}