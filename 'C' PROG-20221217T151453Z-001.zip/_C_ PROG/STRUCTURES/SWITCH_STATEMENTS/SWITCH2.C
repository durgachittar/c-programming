	#include<stdio.h>
	#include<conio.h>

	void main()
	{
		int num1,num2,ans;
		char ch;

		clrscr();
		printf("Enter two numbers ");
		scanf("%d%d",&num1,&num2);
		printf("a. Addition\n");
		printf("s. Subtraction\n");
		printf("d. Multiplication\n");
		printf("m. Division\n");
		printf("Enter the choice :");
		flushall();
		scanf("%c",&ch);
		switch(ch)
		{
			case 'A':
			case 'a':
				ans = num1 + num2;
				printf("Addition = %d",ans);
				break;
			case 'S':
			case 's':
				ans = num1 - num2;
				printf("Subtraction = %d",ans);
				break;
			case'M':
			case 'm':
				ans = num1 * num2;
				printf("Multiplication = %d",ans);
				break;
			case 'D':
			case 'd':
				ans = num1 / num2;
				printf("Division = %d",ans);
				break;
			default:
				printf("You have entered wrong choice");

		}
	}