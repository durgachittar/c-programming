#include<stdio.h>
#include<conio.h>
void main()
{
int r,ch;
int l,b;
float areac,arear;
char choice;
clrscr();
do
{
printf("1.Area of circle\n");
printf("2.Area of rectangle\n");
printf("Enter the choice:");
scanf("%d",&ch);
switch(ch)
{
case 1:
printf("Enter radius\n");
scanf("%d",&r);
areac=3.14*r*r;
printf("Area of circle=%f",areac);
break;

case 2:
printf("Enter length & breath");
scanf("%d%d",&l,&b);
arear=l*b;
printf("Area of rectangle=%f",arear);
break;

default:
printf("u have entered wrong choice");
}
printf("\n do u want to continue(y/n):");
flushall();
scanf("%c",&choice);
}
while(choice=='y'||choice=='Y');
}