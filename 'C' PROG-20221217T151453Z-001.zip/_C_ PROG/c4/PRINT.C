	#include<stdio.h>
	#include<conio.h>

	//stdio - standard input output
	//h - header file
	//conio - console input output
	//void - nothing return to function
	void main()
	{
		clrscr();
		printf("\a Hello world\n ");
		//print the statement to the output screen
		printf("\tBye");
		/*
			Escape sequence
			\n = next line
			\t = tab
			\v = vertical tab
			\b = back space
			\a = alert
			\' = single quote
			\" = double quote
		*/

	}