	#include<stdio.h>
	#include<conio.h>

	void main()
	{
		int num1,num2;
		int ans;

		clrscr();
		printf("Enter the two number :");
		scanf("%d%d",&num1,&num2);
		ans = num1 * num2;
		printf("Answer = %d",ans);

	}