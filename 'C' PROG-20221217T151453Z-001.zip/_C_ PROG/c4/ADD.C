	#include<stdio.h>
	#include<conio.h>

	void main()
	{
		/*
			variable - to store data(value)

			1. Variable name starts with alphabet and _(underscore)
			2. We can write variable name with maximum 32 characters.
			3. Variable name create with alphabet,digit and _.


			syntax
			<data type> <variable name>;
			data type
			1. int   -integer nos    -2 byte 	%d
			2. float -decimal nos    -4 byte        %f
			3. char  -alphabet,digit,-1 byte        %c
				  special chars.

			1. identify data type of variable.
			2. allocate memory for each variable.

			= assignment operator
			+,-,*,/ arithmetic operator
		*/

		int num1,num2;
		int ans;

		clrscr();
		num1 = 10;
		num2 = 20;
		ans = num1 + num2;
		printf("answer = %d",ans);
	}