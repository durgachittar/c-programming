       #include<stdio.h>
       #include<conio.h>

       void main()
       {
		int num1,num2;
		float ans;

		clrscr();
		printf("Enter two numbers :");
		scanf("%d%d",&num1,&num2);

		ans = (float)num1 / num2; //type conversion
		printf("answer = %f",ans);

       }