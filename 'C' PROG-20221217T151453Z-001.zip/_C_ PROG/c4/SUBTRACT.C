	#include<stdio.h>
	#include<conio.h>

	void main()
	{
		int num1,num2;
		int ans;

		clrscr();
		printf("Enter the first number :");
		scanf("%d",&num1);
		//read the value from the keyboard
		//& - store the address of variable
		printf("Enter the second number :");
		scanf("%d",&num2);
		ans = num1 - num2;
		printf("Answer = %d",ans);

	}