	 #include<stdio.h>
	 #include<conio.h>

	 void main()
	 {
		int num1,num2,num3;

		clrscr();
		printf("Enter three numbers :");
		scanf("%d%d%d",&num1,&num2,&num3);

		if(num1>num2 && num1>num3)
		{
			printf("Number1 is greater");
		}

		else if(num2>num1 && num2>num3)
		{
			printf("Number2 is greater");
		}

		else if(num3>num1 && num3>num2)
		{
			printf("Number3 is greater");
		}
		else
		{
			printf("All numbers are same");
		}
	 }