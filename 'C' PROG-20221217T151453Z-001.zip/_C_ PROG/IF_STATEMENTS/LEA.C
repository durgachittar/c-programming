#include<stdio.h>
#include<conio.h>
void main()
{
	int year;
	clrscr();
	printf("Enter the year:");
	scanf("%d",&year);
	if(year%4==0)
	{
		if(year%100==0)
		{
			if(year%400==0)
			{
				printf("Century year and leap year");
			}
			else
			{
				printf("Century year but not leap year");
			}
		}
		else
		{
			printf("Not century but leap year");
		}
	}
	else
	{
		printf("Not century and not leap year");
	}
}