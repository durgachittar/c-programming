	#include<stdio.h>
	#include<conio.h>

	/*
		if (condition)
		{
			statements
		}
		else if(condition)
		{
			statements
		}
		else if(condition)
		{
			statements
		}
		|
		|
		|
		else
		{
			statements
		}

		Relational operator
		>  -  greater than
		<  -  less than
		>= - greater than equal to
		<= - less than equal to
		== - equal to
		!= - not equal to

		When the condition is true then returns 1 value otherwise
		return non zero value.
	*/

	void main()
	{
		int num1,num2;

		clrscr();
		printf("Enter two numbers :");
		scanf("%d%d",&num1,&num2);

		if(num1 > num2)
		{
			printf("Number1 is greater");
		}
		else
		{
			printf("Number2 is greater");
		}
	}