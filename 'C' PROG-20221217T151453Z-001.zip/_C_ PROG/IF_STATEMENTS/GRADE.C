	 #include<stdio.h>
	 #include<conio.h>

	 void main()
	 {
		int mark1,mark2,mark3;
		int total;
		float per;

		clrscr();
		printf("Enter three marks of student :");
		scanf("%d%d%d",&mark1,&mark2,&mark3);

		total = mark1 + mark2 + mark3;
		per = total / 3.0;
		printf("Total = %d \t Per = %f \t ",total,per);

		if(per >= 75)
		{
			printf("Distinction");
		}
		else if(per>=60 && per<75)
		{
			printf("First class");

		}
		else if(per>=50 && per<60)
		{
			printf("Second class");
		}
		else if(per>=35 && per<50)
		{
			printf("Pass");
		}
		else
		{
			printf("Fail");
		}
	 }
