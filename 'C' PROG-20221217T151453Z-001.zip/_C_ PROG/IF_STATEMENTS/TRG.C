	 #include<stdio.h>
	 #include<conio.h>

	 void main()
	 {
		int a,b,c;

		clrscr();
		printf("Enter three sides of triangle :");
		scanf("%d%d%d",&a,&b,&c);

		if(a==b && b==c)
		{
			printf("Equilateral triangle");
		}
		else if(a==b || b==c ||c==a)
		{
			printf("Isosceles triangle");
		}
		else
		{
			printf("Scalene Triangle");
		}
	 }