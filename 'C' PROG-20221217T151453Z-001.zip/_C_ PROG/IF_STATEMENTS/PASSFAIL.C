	#include<stdio.h>
	#include<conio.h>


	void main()
	{
		int mark;

		clrscr();
		printf("Enter the mark :");
		scanf("%d",&mark);

		if(mark >= 35)
		{
			printf("Pass");
		}
		else
		{
			printf("Fail");
		}
	}