#include<stdio.h>
#include<conio.h>
void main()
{
int num1,num2;
int ans;
char ch;
clrscr();
printf("Enter two numbers:");
scanf("%d5d",&num1,&num2);

printf("Enter the choice:");
flushall();
scanf("%c",&ch);

if(ch=='a' || ch=='A')
{
ans =num1+num2;
printf("Answer=%d",ans);
}
else
{
printf("You have entered wrong choice");
}
}