	#include<stdio.h>
	#include<conio.h>


	void main()
	{
		int num;

		clrscr();
		printf("Enter the number :");
		scanf("%d",&num);

		/*
			% - mod - remainder
		*/
		if(num%2 == 0)
		{
			printf("Number is even");
		}
		else
		{
			printf("Number is odd");
		}
	}