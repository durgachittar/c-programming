#include<stdio.h>
#include<conio.h>
void main()
{
char  ch;
clrscr();
printf("Enter a character:");
scanf("%c",&ch);
printf("ch=%c ASCII=%d \n",ch);

if((ch>=65 && ch<=90)|| (ch>=97 && ch<=122))
{
printf("It is an alphabet");
}
else if(ch>=48 && ch<=57)
{
printf("It is a digit");
}
else
{
printf("It is a special case");
}
}
