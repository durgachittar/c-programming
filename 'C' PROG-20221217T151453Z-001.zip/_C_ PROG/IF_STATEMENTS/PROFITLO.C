	 #include<stdio.h>
	 #include<conio.h>

	 void main()
	 {
		float sp,cp;
		float p,l;

		clrscr();
		printf("Enter the values of cp,sp :");
		scanf("%f%f",&cp,&sp);

		if(sp > cp)
		{
			p = ((sp-cp)/cp) * 100;
			printf("Profit = %f",p);
		}
		else if(cp > sp)
		{
			l = ((cp-sp)/cp) * 100;
			printf("Loss = %f",l);
		}
		else
		{
			printf("No profit and no loss");
		}
	 }